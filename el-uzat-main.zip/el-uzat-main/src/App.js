import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import LocationPermission from "./pages/location/LocationPermission";
import "./App.css";
import ManualLocationEntry from "./pages/location/ManualLocationEntry";
import CommunityConfirmation from "./pages/location/CommunityConfirmation";
import MembershipPage from "./pages/MembershipPage";
import Home from "./pages/Home";
import Inbox from "./pages/Inbox";
import ProfilePage from "./pages/ProfilePage";
import CommunityPage from "./pages/CommunityPage";
import Share from "./pages/Share";
import EventsPage from "./pages/event/EventsPage";
import BottomNav from "./components/BottomNav";

function App() {
  return (
    <Router>
      <div className="app-container">
        <Routes>
          <Route path="/" element={<LocationPermission />} />
          <Route path="/home" element={<Home />} />
          <Route path="/manual-entry" element={<ManualLocationEntry />} />
          <Route
            path="/community-confirmation"
            element={<CommunityConfirmation />}
          />
          <Route path="/inbox" element={<Inbox />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/community" element={<CommunityPage />} />
          <Route path="/share" element={<Share />} />
          <Route path="/events" element={<EventsPage />} />
          <Route path="/membership" element={<MembershipPage />} />
        </Routes>
        <BottomNav />
      </div>
    </Router>
  );
}

export default App;