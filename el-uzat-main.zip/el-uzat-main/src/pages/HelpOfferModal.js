import React, { useState } from 'react';
import { 
  Modal, 
  Form, 
  Button, 
  Stack, 
  FormCheck,
  Badge,
  FloatingLabel,
  Alert,
  Image,
  Container,
  ProgressBar
} from 'react-bootstrap';
import { 
  X, 
  Globe, 
  Truck, 
  GeoAlt, 
  Bookmark,
  Camera,
  InfoCircle,
  ChevronDown,
  PersonCircle,
  ArrowLeft,
  Trash
} from 'react-bootstrap-icons';

const HelpOfferModal = ({ show, onHide }) => {
  const [isGlobal, setIsGlobal] = useState(false);
  const [offerShipping, setOfferShipping] = useState(false);
  const [location, setLocation] = useState('');
  const [saveTemplate, setSaveTemplate] = useState(false);
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [postContent, setPostContent] = useState('');
  const [selectedImage, setSelectedImage] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);

  // Modern green theme colors
  const themeColors = {
    primary: '#10B981', // Modern emerald green
    light: '#D1FAE5',
    dark: '#059669',
    icon: '#10B981'
  };

  const handleSubmit = () => {
    if (!location.trim()) {
      return;
    }
    
    console.log({
      postContent,
      isGlobal,
      offerShipping,
      location,
      saveTemplate,
      image: selectedImage
    });
    
    onHide();
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setIsUploading(true);
      setUploadProgress(0);
      
      // Simulate upload progress
      const interval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setIsUploading(false);
            return 100;
          }
          return prev + 10;
        });
      }, 200);
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setSelectedImage(null);
  };

  return (
    <>
      {/* Main Modal */}
      <Modal 
        show={show} 
        onHide={onHide} 
        fullscreen
        centered
        className="modern-help-modal"
        backdrop="static"
      >
        <Modal.Header className="border-0 px-4 pt-3 pb-0">
          <div className="d-flex justify-content-between w-100 align-items-center">
            <Button 
              variant="link" 
              onClick={onHide} 
              className="p-0 text-muted fs-5 close-btn"
            >
              <ArrowLeft size={24} />
            </Button>
            
            <div className="text-center">
              <h4 className="fw-bold" style={{color: themeColors.dark}}>Yardım Teklifi Oluştur</h4>
            </div>
            
            <Button 
              variant="success" 
              className="submit-btn px-3 py-1 rounded-3 fw-medium"
              disabled={!location.trim()}
              style={{
                backgroundColor: themeColors.primary, 
                borderColor: themeColors.primary,
                minWidth: '80px',
                boxShadow: '0 2px 8px rgba(16, 185, 129, 0.3)'
              }}
              onClick={handleSubmit}
            >
              Gönder
            </Button>
          </div>
        </Modal.Header>

        <Modal.Body className="px-4 pb-5">
          {/* User Info */}
          <div className="d-flex align-items-center mb-4">
            <div className="position-relative me-3">
              <PersonCircle className="avatar-icon" size={48} style={{color: themeColors.primary}} />
              <Badge pill bg="success" className="online-badge"></Badge>
            </div>
            <div>
              <div className="fw-bold">Kullanıcı Adı</div>
              <div className="text-muted small">Konum • Şimdi</div>
            </div>
          </div>

          <Form>
            {/* Post Content */}
            <Form.Group className="mb-4">
              <Form.Control
                as="textarea"
                rows={4}
                placeholder="Bugün paylaşmak istediğiniz yardım teklifi nedir?"
                className="post-textarea border-0 p-0 fs-5"
                value={postContent}
                onChange={(e) => setPostContent(e.target.value)}
              />
            </Form.Group>

            {/* Image Upload */}
            {selectedImage && (
              <div className="mb-4 position-relative">
                <Image 
                  src={selectedImage} 
                  alt="Post content" 
                  fluid 
                  rounded 
                  className="w-100"
                  style={{ maxHeight: '300px', objectFit: 'cover' }}
                />
                <Button 
                  variant="danger" 
                  size="sm" 
                  className="position-absolute top-0 end-0 m-2 rounded-circle p-2"
                  onClick={removeImage}
                >
                  <Trash size={16} />
                </Button>
                {isUploading && (
                  <ProgressBar 
                    now={uploadProgress} 
                    label={`${uploadProgress}%`} 
                    className="mt-2"
                    variant="success"
                  />
                )}
              </div>
            )}

            {/* Options */}
            <div className="modern-options">
              <div className="mb-3 p-3 rounded-3 option-container" style={{backgroundColor: themeColors.light + '40'}}>
                <FormCheck
                  type="switch"
                  id="global-visible"
                  label={
                    <span className="d-flex align-items-center option-item">
                      <Globe className="me-2" size={20} style={{color: themeColors.primary}} />
                      Bu gönderiyi herkese görünür yap
                    </span>
                  }
                  checked={isGlobal}
                  onChange={(e) => setIsGlobal(e.target.checked)}
                  className="custom-switch"
                />
              </div>

              <div className="mb-3 p-3 rounded-3 option-container" style={{backgroundColor: themeColors.light + '40'}}>
                <FormCheck
                  type="switch"
                  id="offer-shipping"
                  label={
                    <span className="d-flex align-items-center option-item">
                      <Truck className="me-2" size={20} style={{color: themeColors.primary}} />
                      Kargo ile göndermeyi teklif et
                    </span>
                  }
                  checked={offerShipping}
                  onChange={(e) => setOfferShipping(e.target.checked)}
                  className="custom-switch"
                />
              </div>

              {/* Location Input */}
              <div className="mb-4">
                <div className="section-label mb-2" style={{color: themeColors.primary}}>
                  TESLİMAT KONUMU
                </div>
                <div className="position-relative">
                  <GeoAlt className="input-icon" style={{color: themeColors.primary}} />
                  <Form.Control
                    type="text"
                    placeholder="Önemli bir yer veya kesişen sokaklar"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="location-input py-2 ps-4"
                    style={{borderLeft: `2px solid ${themeColors.primary}`}}
                  />
                </div>
              </div>

              <div className="mb-4 p-3 rounded-3 option-container" style={{backgroundColor: themeColors.light + '40'}}>
                <FormCheck
                  type="switch"
                  id="save-template"
                  label={
                    <span className="d-flex align-items-center option-item">
                      <Bookmark className="me-2" size={18} style={{color: themeColors.primary}} />
                      Bunu sonraki sefer için kaydet
                    </span>
                  }
                  checked={saveTemplate}
                  onChange={(e) => setSaveTemplate(e.target.checked)}
                  className="custom-switch"
                />
              </div>

              {/* Status Select */}
              <div 
                className="status-select mb-4 p-3"
                onClick={() => setShowStatusModal(true)}
                style={{borderLeft: `2px solid ${themeColors.primary}`}}
              >
                <div className="section-label mb-1" style={{color: themeColors.primary}}>
                  GÖNDERİ DURUMU
                </div>
                <div className="d-flex justify-content-between align-items-center">
                  <span>Belirtilmedi</span>
                  <ChevronDown style={{color: themeColors.primary}} />
                </div>
              </div>
            </div>
          </Form>
          
          {/* Camera Button */}
          <div className="camera-btn-container">
            <label htmlFor="post-image-upload" className="camera-btn-label">
              <Button 
                variant="primary" 
                className="camera-btn rounded-circle"
                style={{backgroundColor: themeColors.primary, borderColor: themeColors.primary}}
              >
                <Camera size={22} />
              </Button>
            </label>
            <input 
              id="post-image-upload"
              type="file" 
              accept="image/*" 
              onChange={handleImageUpload}
              className="d-none"
            />
          </div>
        </Modal.Body>
      </Modal>

      {/* Status Modal */}
      <Modal 
        show={showStatusModal} 
        onHide={() => setShowStatusModal(false)} 
        centered
        size="lg"
        className="status-modal"
      >
        <Modal.Header className="border-0 pb-0 px-4 pt-4">
          <Modal.Title className="fw-bold mx-auto modal-title" style={{color: themeColors.dark}}>
            Gönderi Durumu
          </Modal.Title>
          <Button 
            variant="link" 
            onClick={() => setShowStatusModal(false)} 
            className="p-0 close-icon"
          >
            <X size={24} style={{color: themeColors.primary}} />
          </Button>
        </Modal.Header>

        <Modal.Body className="text-center px-5 pb-4">
          <div className="status-icon mx-auto mb-4" style={{backgroundColor: themeColors.light}}>
            <InfoCircle size={60} style={{color: themeColors.primary}} />
          </div>
          <h5 className="fw-bold mb-3" style={{color: themeColors.dark}}>Sürdürülebilir Üye Olun</h5>
          <p className="text-muted mb-4 px-3 status-text">
            Gönderi durumunu ayarlayabilmek ve premium özelliklerin kilidini açmak için
            sürdürülebilir üye olun. Üyelik avantajlarından yararlanarak daha fazla özelliğe
            erişebilirsiniz.
          </p>

          <Stack gap={3} className="mb-3 px-4">
            <Button 
              variant="link" 
              className="fw-medium info-link"
              style={{color: themeColors.primary}}
            >
              Daha Fazla Bilgi Al
            </Button>
            <Button 
              variant="outline-secondary" 
              onClick={() => setShowStatusModal(false)}
              className="cancel-btn py-2"
              style={{borderColor: themeColors.primary, color: themeColors.primary}}
            >
              İptal
            </Button>
          </Stack>
        </Modal.Body>
      </Modal>

      <style jsx>{`
        .modern-help-modal {
          font-family: 'Inter', system-ui, sans-serif;
        }
        
        .modern-help-modal .modal-content {
          border-radius: 0;
          border: none;
          min-height: 100vh;
          background-color: #ffffff;
        }
        
        .close-btn {
          color: #6c757d !important;
          font-weight: 500;
        }
        
        .submit-btn {
          color: white !important;
          transition: all 0.2s ease;
        }
        
        .submit-btn:disabled {
          opacity: 0.65;
          background-color: ${themeColors.light} !important;
          border-color: ${themeColors.light} !important;
          box-shadow: none;
        }
        
        .submit-btn:not(:disabled):hover {
          background-color: ${themeColors.dark} !important;
          border-color: ${themeColors.dark} !important;
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4);
        }
        
        .avatar-icon {
          transition: transform 0.2s;
        }
        
        .avatar-icon:hover {
          transform: scale(1.1);
        }
        
        .online-badge {
          position: absolute;
          bottom: 0;
          right: 0;
          width: 12px;
          height: 12px;
          border: 2px solid white;
          background-color: ${themeColors.primary} !important;
        }
        
        .post-textarea {
          font-size: 18px;
          min-height: 160px;
          line-height: 1.6;
          resize: none;
          background-color: transparent;
        }
        
        .post-textarea:focus {
          box-shadow: none;
          outline: none;
        }
        
        .section-label {
          font-size: 0.75rem;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          font-weight: 600;
        }
        
        .option-item {
          color: #495057;
          padding: 8px 0;
          transition: color 0.2s;
        }
        
        .option-item:hover {
          color: ${themeColors.dark};
        }
        
        .input-icon {
          position: absolute;
          top: 12px;
          left: 12px;
          z-index: 1;
        }
        
        .location-input {
          background-color: #f8f9fa;
          border: none;
          border-radius: 8px;
          padding-left: 35px !important;
          transition: all 0.2s;
        }
        
        .location-input:focus {
          background-color: #fff;
          box-shadow: 0 0 0 2px ${themeColors.light};
        }
        
        .status-select {
          background-color: #f8f9fa;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.2s;
        }
        
        .status-select:hover {
          background-color: #e9ecef;
        }
        
        .camera-btn-container {
          position: fixed;
          bottom: 20px;
          left: 0;
          right: 0;
          display: flex;
          justify-content: center;
          padding: 16px;
          background: linear-gradient(transparent, white 70%);
        }
        
        .camera-btn-label {
          cursor: pointer;
        }
        
        .camera-btn {
          width: 56px;
          height: 56px;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
          transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .camera-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(0, 0, 0, 0.2);
        }
        
        /* Improved switch styles */
        .custom-switch .form-check-input {
          width: 2.5em;
          height: 1.5em;
          margin-right: 0.5em;
          background-color: #e9ecef;
          border: 1px solid #dee2e6;
        }

        .custom-switch .form-check-input:checked {
          background-color: ${themeColors.primary};
          border-color: ${themeColors.primary};
        }

        .custom-switch .form-check-input:focus {
          box-shadow: 0 0 0 0.25rem rgba(16, 185, 129, 0.25);
        }

        .custom-switch .form-check-label {
          cursor: pointer;
        }

        .option-container {
          transition: all 0.2s ease;
        }

        .option-container:hover {
          background-color: ${themeColors.light + '60'} !important;
        }
        
        /* Status Modal Styles */
        .status-modal .modal-content {
          border-radius: 16px;
          border: none;
          box-shadow: 0 8px 30px rgba(0,0,0,0.12);
          max-width: 500px;
          margin: 0 auto;
        }
        
        .modal-title {
          font-size: 1.5rem;
        }
        
        .close-icon {
          transition: opacity 0.2s;
        }
        
        .close-icon:hover {
          opacity: 0.8;
        }
        
        .status-icon {
          width: 90px;
          height: 90px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          transition: transform 0.3s;
        }
        
        .status-icon:hover {
          transform: rotate(10deg);
        }
        
        .status-text {
          line-height: 1.6;
          font-size: 0.95rem;
        }
        
        .info-link {
          text-decoration: none;
          transition: opacity 0.2s;
        }
        
        .info-link:hover {
          opacity: 0.8;
          text-decoration: underline;
        }
        
        .cancel-btn {
          border-radius: 8px;
          transition: all 0.2s;
        }
        
        .cancel-btn:hover {
          background-color: ${themeColors.light};
        }
        
        @media (max-width: 576px) {
          .status-modal .modal-content {
            width: 95%;
          }
          
          .modal-title {
            font-size: 1.25rem;
          }
          
          .status-icon {
            width: 80px;
            height: 80px;
          }
        }
      `}</style>
    </>
  );
};

export default HelpOfferModal;