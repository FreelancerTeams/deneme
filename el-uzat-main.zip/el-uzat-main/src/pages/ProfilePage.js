import React, { useState } from "react";
import {
  Container,
  Tabs,
  Tab,
  Button,
  Image,
  Badge,
  Card,
  ListGroup,
  Modal,
  Form,
  Navbar,
  Stack,
  Row,
  Col,
  Dropdown,
  ProgressBar,
} from "react-bootstrap";
import {
  Gear,
  Pencil,
  Bell,
  Sun,
  Map,
  People,
  Star,
  Heart,
  QuestionCircle,
  ShieldLock,
  FileText,
  Send,
  BoxArrowRight,
  Trash,
  Person,
  Grid3x3Gap,
  Clock,
  Bookmark,
  ChevronLeft,
  X,
  Check,
  Palette,
  Globe,
  ShieldCheck,
  Gift,
  Envelope,
  InfoCircle,
  ThreeDots,
  Chat,
  Share,
  BookmarkCheck,
  Trophy,
  PatchCheck,
  Calendar,
} from "react-bootstrap-icons";

const ProfilePage = () => {
  const [activeTab, setActiveTab] = useState("posts");
  const [showSettings, setShowSettings] = useState(false);
  const [showEditProfile, setShowEditProfile] = useState(false);

  // Kullanıcı verileri
  const user = {
    name: "Yapay Zeka Asistan",
    username: "@yapayzekaai",
    joinDate: "Temmuz 2025",
    community: "İstanbul",
    bio: "Merhaba! Ben bir yapay zeka asistanıyım. Topluluğa yardımcı olmak için buradayım.",
    avatar: "https://randomuser.me/api/portraits/lego/5.jpg",
    stats: {
      posts: 0,
      followers: 24,
      following: 12,
      raves: 0,
    },
    isSupporter: false,
    level: 3,
    progress: 65,
    badges: ["Yeni Üye", "Aktif Katılımcı", "Topluluk Lideri"],
  };

  // Ayarlar seçenekleri
  const settingsSections = [
    {
      title: "Hesap",
      items: [
        {
          icon: <Person />,
          title: "Profil Bilgileri",
          action: () => setShowEditProfile(true),
        },
        { icon: <Bell />, title: "Bildirimler" },
        { icon: <Envelope />, title: "E-posta Tercihleri" },
      ],
    },
    {
      title: "Görünüm",
      items: [
        { icon: <Sun />, title: "Tema", subtitle: "Koyu" },
        { icon: <Palette />, title: "Renk Şeması", subtitle: "Yeşil" },
        { icon: <Globe />, title: "Dil", subtitle: "Türkçe" },
      ],
    },
    {
      title: "Topluluk",
      items: [
        { icon: <Map />, title: "Konum Ayarları" },
        { icon: <People />, title: "Topluluk Yöneticisi Ol" },
        { icon: <ShieldCheck />, title: "Topluluk Taahhüdü" },
      ],
    },
    {
      title: "Üyelik",
      items: [
        { icon: <Star />, title: "Destekçi Üye Ol" },
        { icon: <Gift />, title: "Premium Özellikler" },
      ],
    },
    {
      title: "Diğer",
      items: [
        { icon: <InfoCircle />, title: "Hakkında", subtitle: "v2.3.1" },
        { icon: <QuestionCircle />, title: "Yardım" },
        { icon: <ShieldLock />, title: "Gizlilik Politikası" },
        { icon: <FileText />, title: "Kullanım Şartları" },
        { icon: <Send />, title: "Arkadaş Davet Et" },
        { icon: <BoxArrowRight />, title: "Çıkış Yap", danger: true },
        { icon: <Trash />, title: "Hesabı Sil", danger: true },
      ],
    },
  ];

  return (
    <div className="bg-light" style={{ minHeight: "100vh" }}>
      {/* Ana Navbar */}
      <Navbar bg="white" className="border-bottom sticky-top shadow-sm">
        <Container>
          <Button variant="link" className="p-0 me-2">
            <ChevronLeft size={20} />
          </Button>
          <Navbar.Brand className="fw-bold">Profil</Navbar.Brand>
          <div className="ms-auto">
            <Button
              variant="light"
              className="rounded-circle p-2"
              onClick={() => setShowSettings(true)}
              style={{
                width: "40px",
                height: "40px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Gear size={20} className="text-dark" />
            </Button>
          </div>
        </Container>
      </Navbar>

      {/* Ana İçerik */}
      <Container className="py-3">
        {/* Profil Üst Bilgisi */}
        <Card className="border-0 shadow-sm mb-4 overflow-hidden">
          <div className="position-relative">
            <div
              className="bg-success"
              style={{
                height: "120px",
                background: "linear-gradient(135deg, #28a745, #5cb85c)",
              }}
            ></div>
            <div
              className="position-absolute top-100 start-50 translate-middle"
              style={{ marginTop: "-60px" }}
            >
              <Image
                src={user.avatar}
                roundedCircle
                width={120}
                height={120}
                className="border border-4 border-white shadow"
              />
            </div>
          </div>

          <Card.Body className="text-center mt-5 pt-4">
            <div className="d-flex justify-content-center align-items-center mb-2">
              <h4 className="mb-0 me-2">{user.name}</h4>
              <PatchCheck className="text-primary" size={20} />
            </div>
            <p className="text-muted mb-3">{user.username}</p>

            <div className="d-flex justify-content-center gap-3 mb-3">
              <Button variant="outline-success" size="sm">
                Takip Et
              </Button>
              <Button variant="success" size="sm">
                Mesaj Gönder
              </Button>
            </div>

            {/* İstatistikler */}
            <div className="d-flex justify-content-around text-center mb-4">
              <div className="px-2">
                <div className="fw-bold fs-5">{user.stats.posts}</div>
                <small className="text-muted">Gönderi</small>
              </div>
              <div className="px-2">
                <div className="fw-bold fs-5">{user.stats.followers}</div>
                <small className="text-muted">Takipçi</small>
              </div>
              <div className="px-2">
                <div className="fw-bold fs-5">{user.stats.following}</div>
                <small className="text-muted">Takip</small>
              </div>
              <div className="px-2">
                <div className="fw-bold fs-5">{user.stats.raves}</div>
                <small className="text-muted">Takdir</small>
              </div>
            </div>

            {/* Seviye Çubuğu */}
            <div className="mb-3">
              <div className="d-flex justify-content-between mb-1">
                <small className="text-muted">Seviye {user.level}</small>
                <small className="text-success fw-bold">{user.progress}%</small>
              </div>
              <ProgressBar
                now={user.progress}
                variant="success"
                className="rounded-pill"
                style={{ height: "6px" }}
              />
            </div>
          </Card.Body>
        </Card>

        {/* Sekmeler */}
        <Tabs
          activeKey={activeTab}
          onSelect={(k) => setActiveTab(k)}
          className="mb-3"
          fill
        >
          <Tab
            eventKey="posts"
            title={
              <>
                <Grid3x3Gap size={16} className="me-1" /> Gönderiler
              </>
            }
          />
          <Tab
            eventKey="activity"
            title={
              <>
                <Clock size={16} className="me-1" /> Aktivite
              </>
            }
          />
          <Tab
            eventKey="profile"
            title={
              <>
                <Person size={16} className="me-1" /> Profil
              </>
            }
          />
        </Tabs>

        {/* Sekme İçerikleri */}
        {activeTab === "posts" && (
          <div className="text-center py-5">
            <Image
              src="/empty-state.svg"
              width={150}
              className="mb-4 opacity-50"
            />
            <h5>Aktif Gönderiniz Yok</h5>
            <p className="text-muted mb-3">
              Henüz aktif bir gönderi paylaşmadınız
            </p>
            <Button variant="success" className="rounded-pill px-4">
              Yeni Gönderi Oluştur
            </Button>
          </div>
        )}

        {activeTab === "activity" && (
          <div className="text-center py-5">
            <Image
              src="/activity-empty.svg"
              width={150}
              className="mb-4 opacity-50"
            />
            <h5>Henüz Aktiviteniz Yok</h5>
            <p className="text-muted">Henüz bir aktivite kaydınız bulunmuyor</p>
          </div>
        )}

        {activeTab === "profile" && (
          <div className="bg-white rounded-3 shadow-sm overflow-hidden">
            <div className="p-4">
              <h5 className="mb-3 d-flex align-items-center">
                <Person className="me-2 text-success" size={20} />
                Hakkımda
              </h5>
              <p className="mb-4">{user.bio}</p>

              <Button
                variant="outline-success"
                className="rounded-pill"
                onClick={() => setShowEditProfile(true)}
              >
                <Pencil className="me-1" /> Profili Düzenle
              </Button>
            </div>

            <div className="border-top p-4">
              <h5 className="mb-3 d-flex align-items-center">
                <Trophy className="me-2 text-success" size={20} />
                Topluluk Bilgileri
              </h5>

              <ListGroup variant="flush" className="rounded">
                <ListGroup.Item className="d-flex justify-content-between align-items-center px-0 py-3 border-0">
                  <div className="d-flex align-items-center">
                    <Calendar className="text-muted me-2" size={18} />
                    <span>Katılma Tarihi</span>
                  </div>
                  <span className="text-muted">{user.joinDate}</span>
                </ListGroup.Item>
                <ListGroup.Item className="d-flex justify-content-between align-items-center px-0 py-3 border-0">
                  <div className="d-flex align-items-center">
                    <Map className="text-muted me-2" size={18} />
                    <span>Topluluk</span>
                  </div>
                  <span className="text-muted">{user.community}</span>
                </ListGroup.Item>
                <ListGroup.Item className="d-flex justify-content-between align-items-center px-0 py-3 border-0">
                  <div className="d-flex align-items-center">
                    <ShieldCheck className="text-muted me-2" size={18} />
                    <span>Topluluk Yöneticisi</span>
                  </div>
                  <Badge bg="secondary" pill>
                    Hayır
                  </Badge>
                </ListGroup.Item>
              </ListGroup>
            </div>

            <div className="border-top p-4">
              <h5 className="mb-3 d-flex align-items-center">
                <BookmarkCheck className="me-2 text-success" size={20} />
                Rozetler
              </h5>

              <div className="d-flex flex-wrap gap-2">
                {user.badges.map((badge, index) => (
                  <Badge
                    key={index}
                    bg="light"
                    text="dark"
                    pill
                    className="d-flex align-items-center py-2 px-3 border"
                  >
                    <Star className="text-warning me-1" size={14} />
                    {badge}
                  </Badge>
                ))}
              </div>
            </div>

            {!user.isSupporter && (
              <div className="border-top p-4">
                <Card className="border-0 bg-light-green">
                  <Card.Body className="text-center p-4">
                    <div className="bg-success bg-opacity-10 d-inline-block p-3 rounded-circle mb-3">
                      <Star size={24} className="text-success" />
                    </div>
                    <h5 className="mb-2">Destekçi Üye Olun</h5>
                    <p className="text-muted mb-3">
                      Premium özelliklerin kilidini açın ve topluluğumuza destek
                      olun
                    </p>
                    <Button variant="success" className="rounded-pill px-4">
                      Destekçi Üye Ol
                    </Button>
                  </Card.Body>
                </Card>
              </div>
            )}
          </div>
        )}
      </Container>

      {/* Tam Sayfa Ayarlar Modalı */}
      <Modal
        show={showSettings}
        onHide={() => setShowSettings(false)}
        fullscreen
        className="settings-modal"
      >
        <Modal.Header className="border-bottom sticky-top bg-white">
          <Container>
            <div className="d-flex align-items-center">
              <Button
                variant="link"
                className="p-0 me-3"
                onClick={() => setShowSettings(false)}
              >
                <ChevronLeft size={20} />
              </Button>
              <Modal.Title className="fw-bold">Ayarlar</Modal.Title>
            </div>
          </Container>
        </Modal.Header>
        <Modal.Body>
          <Container>
            {settingsSections.map((section, index) => (
              <div key={index} className="mb-4">
                <h6 className="text-muted mb-3 px-2">{section.title}</h6>
                <Card className="border-0 shadow-sm">
                  <ListGroup variant="flush">
                    {section.items.map((item, itemIndex) => (
                      <ListGroup.Item
                        key={itemIndex}
                        action
                        className={`d-flex align-items-center px-3 py-3 ${
                          item.danger ? "text-danger" : ""
                        }`}
                        onClick={item.action}
                      >
                        <div className="me-3" style={{ width: "24px" }}>
                          {React.cloneElement(item.icon, {
                            className: item.danger
                              ? "text-danger"
                              : "text-success",
                          })}
                        </div>
                        <div className="flex-grow-1">
                          <div>{item.title}</div>
                          {item.subtitle && (
                            <small className="text-muted">
                              {item.subtitle}
                            </small>
                          )}
                        </div>
                        {!item.danger && <ChevronLeft className="text-muted" />}
                      </ListGroup.Item>
                    ))}
                  </ListGroup>
                </Card>
              </div>
            ))}
          </Container>
        </Modal.Body>
      </Modal>

      {/* Profil Düzenleme Modalı */}
      <Modal
        show={showEditProfile}
        onHide={() => setShowEditProfile(false)}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>Profili Düzenle</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <div className="text-center mb-4">
              <div className="position-relative d-inline-block">
                <Image
                  src={user.avatar}
                  roundedCircle
                  width={120}
                  height={120}
                  className="mb-2 border border-4 border-success border-opacity-25"
                />
                <Button
                  variant="success"
                  size="sm"
                  className="position-absolute bottom-0 end-0 rounded-circle p-2"
                >
                  <Pencil size={14} />
                </Button>
              </div>
            </div>

            <Form.Group className="mb-3">
              <Form.Label>Ad Soyad</Form.Label>
              <Form.Control
                type="text"
                defaultValue={user.name}
                className="py-2"
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Kullanıcı Adı</Form.Label>
              <Form.Control
                type="text"
                defaultValue={user.username}
                className="py-2"
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Hakkımda</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                defaultValue={user.bio}
                className="py-2"
                style={{ minHeight: "100px" }}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button
            variant="light"
            onClick={() => setShowEditProfile(false)}
            className="px-4"
          >
            İptal
          </Button>
          <Button
            variant="success"
            onClick={() => setShowEditProfile(false)}
            className="px-4"
          >
            Kaydet
          </Button>
        </Modal.Footer>
      </Modal>

      {/* CSS Stilleri */}
      <style>{`
        .bg-light-green {
          background-color: rgba(40, 167, 69, 0.05) !important;
        }
        .settings-modal .modal-content {
          border-radius: 0;
          border: none;
        }
        .settings-modal .modal-header {
          padding: 1rem;
          box-shadow: 0 1px 2px rgba(0,0,0,0.1);
        }
        .nav-tabs {
          border-bottom: none;
        }
        .nav-tabs .nav-link {
          border: none;
          color: #495057;
          font-weight: 500;
          padding: 0.75rem;
          transition: all 0.2s;
        }
        .nav-tabs .nav-link.active {
          color: #28a745;
          background: transparent;
          position: relative;
        }
        .nav-tabs .nav-link.active:after {
          content: '';
          position: absolute;
          bottom: 0;
          left: 50%;
          transform: translateX(-50%);
          width: 30px;
          height: 3px;
          background-color: #28a745;
          border-radius: 3px;
        }
        .nav-tabs .nav-link:hover {
          border-color: transparent;
          color: #28a745;
        }
      `}</style>
    </div>
  );
};

export default ProfilePage;
