import React, { useState, useEffect } from "react";
import {
  Container,
  Row,
  Col,
  Navbar,
  Button,
  Card,
  ListGroup,
  Badge,
  Form,
  InputGroup,
  Tab,
  Tabs,
  Image,
  Stack,
  Dropdown,
  Modal,
  Alert,
  Spinner,
  Offcanvas,
  Toast,
  ToastContainer,
  FloatingLabel,
  OverlayTrigger,
  Tooltip,
  Accordion,
} from "react-bootstrap";
import {
  Search,
  House,
  Inbox,
  Share,
  Person,
  People,
  ChevronLeft,
  CheckCircle,
  ThreeDots,
  Star,
  StarFill,
  Trash,
  Reply,
  Envelope,
  EnvelopeOpen,
  Plus,
  Funnel,
  ArrowClockwise,
  ArrowRepeat,
  Paperclip,
  EmojiSmile,
  Send,
  X,
  Check,
  ExclamationTriangle,
  Clock,
  PersonPlus,
  PersonCheck,
  ChatLeftText,
  ListUl,
  Gear,
  Filter,
  Archive,
  Pin,
  PinFill,
} from "react-bootstrap-icons";

const InboxPage = () => {
  const [activeTab, setActiveTab] = useState("inbox");
  const [selectedMessage, setSelectedMessage] = useState(null);
  const [showComposeModal, setShowComposeModal] = useState(false);
  const [starredMessages, setStarredMessages] = useState([2, 4]);
  const [searchQuery, setSearchQuery] = useState("");
  const [showUserList, setShowUserList] = useState(false);
  const [showDeleteToast, setShowDeleteToast] = useState(false);
  const [deletedMessage, setDeletedMessage] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [replyContent, setReplyContent] = useState("");
  const [pinnedMessages, setPinnedMessages] = useState([1]);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState([]);

  // Kullanıcı listesi
  const users = [
    {
      id: 1,
      name: "Ayşe Yılmaz",
      location: "Ankara",
      avatar: "https://randomuser.me/api/portraits/women/32.jpg",
      status: "online",
    },
    {
      id: 2,
      name: "Mehmet Kaya",
      location: "İstanbul",
      avatar: "https://randomuser.me/api/portraits/men/45.jpg",
      status: "away",
    },
    {
      id: 3,
      name: "Zeynep Demir",
      location: "İzmir",
      avatar: "https://randomuser.me/api/portraits/women/65.jpg",
      status: "offline",
    },
    {
      id: 4,
      name: "BuyNothing Topluluğu",
      location: "",
      avatar:
        "https://storage.googleapis.com/a1aa/image/e49a3766-3c66-4442-1a73-44d992e0e01a.jpg",
      status: "online",
    },
    {
      id: 5,
      name: "Ali Veli",
      location: "Bursa",
      avatar: "https://randomuser.me/api/portraits/men/22.jpg",
      status: "online",
    },
  ];

  const messages = [
    {
      id: 1,
      sender: "Ayşe Yılmaz (Ankara)",
      senderId: 1,
      avatar: "https://randomuser.me/api/portraits/women/32.jpg",
      subject: "Köpeğinizi yürütebilirim",
      preview:
        "Merhaba, bu hafta sonu köpeğinizi yürütebilirim. Kendim de golden retriever sahibiyim...",
      time: "2 saat önce",
      read: false,
      type: "help-offer",
      category: "community",
      status: "unread",
      attachments: [],
    },
    {
      id: 2,
      sender: "Mehmet Kaya (İstanbul)",
      senderId: 2,
      avatar: "https://randomuser.me/api/portraits/men/45.jpg",
      subject: "Eski kitaplarımı paylaşıyorum",
      preview:
        "Merhaba, kullanmadığım birkaç kitabım var. İlgilenirseniz getirebilirim...",
      time: "1 gün önce",
      read: true,
      type: "share",
      category: "individual",
      status: "read",
      attachments: [{ name: "kitap-listesi.pdf", size: "2.4MB" }],
    },
    {
      id: 3,
      sender: "BuyNothing Topluluğu",
      senderId: 4,
      avatar:
        "https://storage.googleapis.com/a1aa/image/e49a3766-3c66-4442-1a73-44d992e0e01a.jpg",
      subject: "Topluluk kuralları güncellendi",
      preview:
        "Sevgili üyelerimiz, topluluk kurallarımızda küçük güncellemeler yapılmıştır...",
      time: "3 gün önce",
      read: true,
      type: "system",
      category: "community",
      status: "read",
      attachments: [{ name: "yeni-kurallar.pdf", size: "1.2MB" }],
    },
    {
      id: 4,
      sender: "Zeynep Demir (İzmir)",
      senderId: 3,
      avatar: "https://randomuser.me/api/portraits/women/65.jpg",
      subject: "Yardım teklifinizi kabul ediyorum",
      preview:
        "Teşekkür ederim! Yardım teklifinizi kabul etmek istiyorum. Detayları konuşabilir miyiz?",
      time: "5 gün önce",
      read: true,
      type: "help-accept",
      category: "individual",
      status: "read",
      attachments: [],
    },
  ];

  // Filtrelenmiş mesajlar
  const filteredMessages = messages.filter((msg) => {
    const matchesSearch =
      searchQuery === "" ||
      msg.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      msg.sender.toLowerCase().includes(searchQuery.toLowerCase()) ||
      msg.preview.toLowerCase().includes(searchQuery.toLowerCase());

    if (activeTab === "inbox") return matchesSearch;
    if (activeTab === "starred")
      return starredMessages.includes(msg.id) && matchesSearch;
    if (activeTab === "pinned")
      return pinnedMessages.includes(msg.id) && matchesSearch;
    if (activeTab === "unread") return !msg.read && matchesSearch;
    return matchesSearch;
  });

  // Mesajı yıldızla
  const toggleStar = (id, e) => {
    e?.stopPropagation();
    if (starredMessages.includes(id)) {
      setStarredMessages(starredMessages.filter((msgId) => msgId !== id));
    } else {
      setStarredMessages([...starredMessages, id]);
    }
  };

  // Mesajı sabitle
  const togglePin = (id, e) => {
    e?.stopPropagation();
    if (pinnedMessages.includes(id)) {
      setPinnedMessages(pinnedMessages.filter((msgId) => msgId !== id));
    } else {
      setPinnedMessages([...pinnedMessages, id]);
    }
  };

  // Mesajı sil
  const deleteMessage = (id, e) => {
    e?.stopPropagation();
    const messageToDelete = messages.find((msg) => msg.id === id);
    setDeletedMessage(messageToDelete);
    setShowDeleteToast(true);

    // Simüle edilmiş API çağrısı
    setIsLoading(true);
    setTimeout(() => {
      if (selectedMessage?.id === id) {
        setSelectedMessage(null);
      }
      setIsLoading(false);
    }, 1000);
  };

  // Mesajı okundu olarak işaretle
  const markAsRead = (id) => {
    // Gerçek uygulamada burada API çağrısı yapılır
    console.log(`Mesaj ${id} okundu olarak işaretlendi`);
  };

  // Mesaj seçildiğinde okundu olarak işaretle
  useEffect(() => {
    if (selectedMessage && !selectedMessage.read) {
      markAsRead(selectedMessage.id);
    }
  }, [selectedMessage]);

  // Kullanıcı seçimi
  const toggleUserSelection = (userId) => {
    if (selectedUsers.includes(userId)) {
      setSelectedUsers(selectedUsers.filter((id) => id !== userId));
    } else {
      setSelectedUsers([...selectedUsers, userId]);
    }
  };

  return (
    <div className="d-flex flex-column min-vh-100 bg-light">
      {/* Üst Navigasyon */}
      <Navbar
        bg="white"
        expand="lg"
        className="border-bottom py-2 px-3 shadow-sm sticky-top"
      >
        <Navbar.Brand className="d-flex align-items-center">
          <Button variant="link" className="me-2 p-0 text-dark d-lg-none">
            <ChevronLeft size={20} />
          </Button>
          <span className="fw-bold">Mesajlar</span>
          <Badge bg="success" className="ms-2" pill>
            {messages.filter((m) => !m.read).length}
          </Badge>
        </Navbar.Brand>

        <div className="d-flex ms-auto gap-2">
          <Button
            variant="outline-success"
            className="d-flex align-items-center"
            onClick={() => setShowComposeModal(true)}
          >
            <Plus size={16} className="me-1" />
            <span className="d-none d-md-inline">Yeni Mesaj</span>
          </Button>

          <Button
            variant="outline-secondary"
            onClick={() => setShowFilters(!showFilters)}
            active={showFilters}
          >
            <Filter size={16} />
          </Button>

          <Button
            variant="outline-secondary"
            onClick={() => setShowUserList(true)}
          >
            <People size={16} />
          </Button>
        </div>
      </Navbar>

      {/* Filtre Paneli */}
      {showFilters && (
        <div className="bg-white border-bottom p-3 shadow-sm">
          <div className="d-flex flex-wrap gap-2">
            <Button
              variant={activeTab === "inbox" ? "primary" : "outline-secondary"}
              onClick={() => setActiveTab("inbox")}
              size="sm"
            >
              Tümü
            </Button>
            <Button
              variant={activeTab === "unread" ? "primary" : "outline-secondary"}
              onClick={() => setActiveTab("unread")}
              size="sm"
            >
              Okunmamışlar
            </Button>
            <Button
              variant={
                activeTab === "starred" ? "primary" : "outline-secondary"
              }
              onClick={() => setActiveTab("starred")}
              size="sm"
            >
              Yıldızlı
            </Button>
            <Button
              variant={activeTab === "pinned" ? "primary" : "outline-secondary"}
              onClick={() => setActiveTab("pinned")}
              size="sm"
            >
              Sabitlenenler
            </Button>
          </div>
        </div>
      )}

      {/* Ana İçerik */}
      <Container fluid className="flex-grow-1 p-0 overflow-hidden bg-white">
        <Row className="h-100 g-0">
          {/* Mesaj Listesi */}
          <Col lg={4} className="h-100 border-end overflow-auto">
            <div className="sticky-top bg-white pt-3 pb-2 border-bottom shadow-sm">
              <div className="px-3 pb-2">
                <InputGroup>
                  <Form.Control
                    placeholder="Mesajlarda ara..."
                    aria-label="Mesajlarda ara"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="border-end-0"
                  />
                  <Button
                    variant="outline-secondary"
                    className="border-start-0"
                  >
                    <Search />
                  </Button>
                </InputGroup>
              </div>
            </div>

            {isLoading ? (
              <div className="d-flex justify-content-center align-items-center py-5">
                <Spinner animation="border" variant="primary" />
              </div>
            ) : filteredMessages.length === 0 ? (
              <div className="text-center py-5 text-muted">
                <Envelope size={32} className="mb-3 opacity-50" />
                <h5>Mesaj bulunamadı</h5>
                <p>Arama kriterlerinize uygun mesaj bulunamadı</p>
                <Button
                  variant="outline-primary"
                  size="sm"
                  onClick={() => {
                    setSearchQuery("");
                    setActiveTab("inbox");
                  }}
                >
                  Filtreyi temizle
                </Button>
              </div>
            ) : (
              <ListGroup variant="flush" className="message-list">
                {filteredMessages.map((message) => (
                  <ListGroup.Item
                    key={message.id}
                    action
                    active={selectedMessage?.id === message.id}
                    onClick={() => setSelectedMessage(message)}
                    className={`border-0 py-3 message-item ${
                      !message.read ? "unread" : ""
                    } ${pinnedMessages.includes(message.id) ? "pinned" : ""}`}
                  >
                    <Stack
                      direction="horizontal"
                      gap={2}
                      className="align-items-center"
                    >
                      <Stack gap={1} className="me-1">
                        <Button
                          variant="link"
                          className="p-0 text-muted hover-primary"
                          onClick={(e) => toggleStar(message.id, e)}
                          size="sm"
                        >
                          {starredMessages.includes(message.id) ? (
                            <StarFill className="text-warning" />
                          ) : (
                            <Star />
                          )}
                        </Button>
                        {pinnedMessages.includes(message.id) ? (
                          <PinFill className="text-primary small" />
                        ) : (
                          <Pin className="text-muted small opacity-0 message-pin" />
                        )}
                      </Stack>

                      <Image
                        src={message.avatar}
                        roundedCircle
                        width={48}
                        height={48}
                        className="me-3 flex-shrink-0"
                        thumbnail
                      />

                      <div className="flex-grow-1 overflow-hidden">
                        <div className="d-flex justify-content-between align-items-center mb-1">
                          <span
                            className={`fw-bold ${
                              !message.read ? "text-dark" : "text-muted"
                            }`}
                          >
                            {message.sender}
                          </span>
                          <small className="text-muted">{message.time}</small>
                        </div>
                        <div
                          className={`text-truncate ${
                            !message.read ? "fw-semibold" : ""
                          }`}
                        >
                          {message.subject}
                        </div>
                        <div className="text-truncate text-muted small">
                          {message.preview}
                        </div>

                        <div className="d-flex gap-2 mt-1">
                          {message.category === "community" && (
                            <Badge
                              bg="info"
                              pill
                              className="d-flex align-items-center"
                            >
                              <People size={12} className="me-1" />
                              Topluluk
                            </Badge>
                          )}
                          {message.attachments.length > 0 && (
                            <Badge
                              bg="secondary"
                              pill
                              className="d-flex align-items-center"
                            >
                              <Paperclip size={12} className="me-1" />
                              Ek
                            </Badge>
                          )}
                        </div>
                      </div>

                      {!message.read && (
                        <span className="ms-2">
                          <span className="badge-dot bg-success"></span>
                        </span>
                      )}
                    </Stack>
                  </ListGroup.Item>
                ))}
              </ListGroup>
            )}
          </Col>

          {/* Mesaj Detayı */}
          <Col
            lg={8}
            className="h-100 overflow-auto d-none d-lg-block bg-light"
          >
            {selectedMessage ? (
              <div className="p-4 h-100 d-flex flex-column">
                <div className="d-flex justify-content-between align-items-center mb-4">
                  <div className="d-flex align-items-center">
                    <h4 className="mb-0 d-flex align-items-center">
                      {pinnedMessages.includes(selectedMessage.id) && (
                        <PinFill className="text-primary me-2" />
                      )}
                      {selectedMessage.subject}
                    </h4>
                  </div>
                  <div className="d-flex gap-2">
                    <OverlayTrigger
                      placement="bottom"
                      overlay={<Tooltip>Yanıtla</Tooltip>}
                    >
                      <Button variant="outline-secondary" size="sm">
                        <Reply />
                      </Button>
                    </OverlayTrigger>

                    <OverlayTrigger
                      placement="bottom"
                      overlay={<Tooltip>İlet</Tooltip>}
                    >
                      <Button variant="outline-secondary" size="sm">
                        <ArrowRepeat />
                      </Button>
                    </OverlayTrigger>

                    <Dropdown>
                      <Dropdown.Toggle variant="outline-secondary" size="sm">
                        <ThreeDots />
                      </Dropdown.Toggle>
                      <Dropdown.Menu>
                        <Dropdown.Item
                          onClick={(e) => toggleStar(selectedMessage.id, e)}
                        >
                          {starredMessages.includes(selectedMessage.id) ? (
                            <>
                              <StarFill className="text-warning me-2" />
                              Yıldızı kaldır
                            </>
                          ) : (
                            <>
                              <Star className="me-2" />
                              Yıldızla
                            </>
                          )}
                        </Dropdown.Item>
                        <Dropdown.Item
                          onClick={(e) => togglePin(selectedMessage.id, e)}
                        >
                          {pinnedMessages.includes(selectedMessage.id) ? (
                            <>
                              <PinFill className="text-primary me-2" />
                              Sabitlemeyi kaldır
                            </>
                          ) : (
                            <>
                              <Pin className="me-2" />
                              Sabitle
                            </>
                          )}
                        </Dropdown.Item>
                        <Dropdown.Divider />
                        <Dropdown.Item
                          onClick={(e) => deleteMessage(selectedMessage.id, e)}
                        >
                          <Trash className="me-2 text-danger" />
                          <span className="text-danger">Sil</span>
                        </Dropdown.Item>
                      </Dropdown.Menu>
                    </Dropdown>
                  </div>
                </div>

                <div className="d-flex align-items-center mb-4">
                  <div className="position-relative me-3">
                    <Image
                      src={selectedMessage.avatar}
                      roundedCircle
                      width={56}
                      height={56}
                      className="me-3"
                    />
                    {users.find((u) => u.id === selectedMessage.senderId)
                      ?.status === "online" && (
                      <span className="position-absolute bottom-0 end-0 p-1 bg-success border border-2 border-white rounded-circle"></span>
                    )}
                  </div>
                  <div className="flex-grow-1">
                    <div className="fw-bold d-flex align-items-center">
                      {selectedMessage.sender}
                      {users.find((u) => u.id === selectedMessage.senderId)
                        ?.status === "online" && (
                        <small className="text-success ms-2 d-flex align-items-center">
                          <span className="badge-dot bg-success me-1"></span>
                          Çevrimiçi
                        </small>
                      )}
                    </div>
                    <div className="text-muted small d-flex align-items-center">
                      {selectedMessage.time}
                      {selectedMessage.attachments.length > 0 && (
                        <Button
                          variant="link"
                          className="text-decoration-none p-0 ms-2 d-flex align-items-center"
                        >
                          <Paperclip size={12} className="me-1" />
                          <small>{selectedMessage.attachments.length} ek</small>
                        </Button>
                      )}
                    </div>
                  </div>
                  <Button variant="outline-primary" size="sm">
                    <PersonPlus size={14} className="me-1" />
                    Takip et
                  </Button>
                </div>

                <div className="mb-4 flex-grow-1">
                  {selectedMessage.type === "help-offer" && (
                    <Alert
                      variant="success"
                      className="d-flex align-items-center"
                    >
                      <CheckCircle size={24} className="me-2 flex-shrink-0" />
                      <div>
                        <Alert.Heading>Yardım Teklifi</Alert.Heading>
                        <p className="mb-0">
                          Bu kişi size yardım teklif ediyor
                        </p>
                      </div>
                    </Alert>
                  )}

                  {selectedMessage.type === "help-accept" && (
                    <Alert variant="info" className="d-flex align-items-center">
                      <CheckCircle size={24} className="me-2 flex-shrink-0" />
                      <div>
                        <Alert.Heading>Yardım Kabulü</Alert.Heading>
                        <p className="mb-0">
                          Bu kişi yardım teklifinizi kabul etti
                        </p>
                      </div>
                    </Alert>
                  )}

                  <div className="border rounded p-4 mb-4 bg-white shadow-sm">
                    <p>Merhaba,</p>
                    <p>
                      {selectedMessage.preview} Lorem ipsum dolor sit amet,
                      consectetur adipiscing elit. Nullam euismod, nisl eget
                      aliquam ultricies, nunc nisl aliquet nunc, quis aliquam
                      nisl nunc eu nisl.
                    </p>
                    <p>
                      Saygılarımla,
                      <br />
                      {selectedMessage.sender.split(" ")[0]}
                    </p>

                    {selectedMessage.attachments.length > 0 && (
                      <div className="mt-4">
                        <h6 className="mb-3">
                          <Paperclip className="me-2" />
                          Ekler ({selectedMessage.attachments.length})
                        </h6>
                        <div className="d-flex flex-wrap gap-2">
                          {selectedMessage.attachments.map((file, index) => (
                            <Card
                              key={index}
                              className="border p-2"
                              style={{ width: "120px" }}
                            >
                              <div className="text-center mb-2">
                                <Paperclip size={24} />
                              </div>
                              <small className="d-block text-truncate">
                                {file.name}
                              </small>
                              <small className="text-muted">{file.size}</small>
                            </Card>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {selectedMessage.type === "help-offer" && (
                    <div className="d-flex gap-2 mb-4">
                      <Button variant="success" className="flex-grow-1">
                        <CheckCircle className="me-2" />
                        Teklifi Kabul Et
                      </Button>
                      <Button
                        variant="outline-secondary"
                        className="flex-grow-1"
                      >
                        Teşekkür Edip Reddet
                      </Button>
                    </div>
                  )}
                </div>

                <div className="border-top pt-3 mt-auto">
                  <h5 className="mb-3 d-flex align-items-center">
                    <ChatLeftText className="me-2" />
                    Yanıtla
                  </h5>
                  <Form.Group className="mb-3">
                    <FloatingLabel
                      controlId="replyTextarea"
                      label="Mesajınızı buraya yazın..."
                    >
                      <Form.Control
                        as="textarea"
                        style={{ height: "100px" }}
                        value={replyContent}
                        onChange={(e) => setReplyContent(e.target.value)}
                      />
                    </FloatingLabel>
                  </Form.Group>
                  <div className="d-flex justify-content-between align-items-center mb-3">
                    <div className="d-flex gap-2">
                      <Button variant="outline-secondary" size="sm">
                        <Paperclip size={16} />
                      </Button>
                      <Button variant="outline-secondary" size="sm">
                        <EmojiSmile size={16} />
                      </Button>
                    </div>
                    <div className="d-flex gap-2">
                      <Button variant="outline-secondary">
                        <ArrowRepeat className="me-1" />
                        İlet
                      </Button>
                      <Button variant="primary">
                        <Send className="me-1" />
                        Gönder
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div
                className="d-flex flex-column align-items-center justify-content-center"
                style={{
                  height: "80vh", // Increased height
                  width: "100%",
                  backgroundColor: "#f8f9fa", // Light gray background
                  padding: "3rem",
                }}
              >
                <div className="text-center" style={{ maxWidth: "500px" }}>
                  <div
                    className="bg-success bg-opacity-10 p-4 rounded-circle d-inline-block mb-4"
                    style={{
                      width: "100px",
                      height: "100px",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <EnvelopeOpen size={48} className="text-success" />
                  </div>
                  <h3 className="fw-bold mb-3">Mesaj Seçin</h3>
                  <p className="text-muted mb-4 fs-5">
                    Detaylarını görüntülemek için soldaki listeden bir mesaj
                    seçin
                    <br />
                    veya yeni bir mesaj oluşturun
                  </p>
                  <Button
                    variant="success"
                    size="md" // Changed from lg to md for smaller size
                    onClick={() => setShowComposeModal(true)}
                    className="px-4 py-2 fw-medium" // Reduced padding
                    style={{
                      fontSize: "0.9rem", // Slightly smaller text
                    }}
                  >
                    <Plus size={18} className="me-2" />
                    Yeni Mesaj Oluştur
                  </Button>
                </div>
              </div>
            )}
          </Col>
        </Row>
      </Container>

      {/* Kullanıcı Listesi Offcanvas */}
      <Offcanvas
        show={showUserList}
        onHide={() => setShowUserList(false)}
        placement="end"
      >
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>Topluluk Üyeleri</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          <div className="mb-3">
            <InputGroup>
              <Form.Control
                placeholder="Üyelerde ara..."
                aria-label="Üyelerde ara"
              />
              <Button variant="outline-secondary">
                <Search />
              </Button>
            </InputGroup>
          </div>

          <ListGroup variant="flush">
            {users.map((user) => (
              <ListGroup.Item key={user.id} className="border-0 py-2 px-0">
                <div className="d-flex align-items-center">
                  <div className="position-relative me-3">
                    <Image
                      src={user.avatar}
                      roundedCircle
                      width={48}
                      height={48}
                      className="me-3"
                    />
                    {user.status === "online" && (
                      <span className="position-absolute bottom-0 end-0 p-1 bg-success border border-2 border-white rounded-circle"></span>
                    )}
                  </div>
                  <div className="flex-grow-1">
                    <div className="fw-bold">{user.name}</div>
                    <div className="text-muted small">
                      {user.location && `${user.location} • `}
                      {user.status === "online"
                        ? "Çevrimiçi"
                        : user.status === "away"
                        ? "Uzakta"
                        : "Çevrimdışı"}
                    </div>
                  </div>
                  <Button
                    variant={
                      selectedUsers.includes(user.id)
                        ? "success"
                        : "outline-success"
                    }
                    size="sm"
                    onClick={() => toggleUserSelection(user.id)}
                  >
                    {selectedUsers.includes(user.id) ? (
                      <>
                        <PersonCheck className="me-1" />
                        Seçildi
                      </>
                    ) : (
                      <>
                        <PersonPlus className="me-1" />
                        Seç
                      </>
                    )}
                  </Button>
                </div>
              </ListGroup.Item>
            ))}
          </ListGroup>

          {selectedUsers.length > 0 && (
            <div className="position-sticky bottom-0 bg-white pt-3 pb-2 border-top mt-3">
              <Button
                variant="primary"
                className="w-100"
                onClick={() => {
                  setShowUserList(false);
                  setShowComposeModal(true);
                }}
              >
                <Send className="me-2" />
                {selectedUsers.length} kişiye mesaj gönder
              </Button>
            </div>
          )}
        </Offcanvas.Body>
      </Offcanvas>

      {/* Alt Navigasyon (Mobil) */}
      <Navbar
        bg="white"
        fixed="bottom"
        className="border-top justify-content-around py-2 d-lg-none shadow-sm"
      >
        <Button
          variant="link"
          className="text-dark d-flex flex-column align-items-center"
        >
          <House size={20} />
          <small>Ana Sayfa</small>
        </Button>
        <Button
          variant="link"
          className="text-primary d-flex flex-column align-items-center position-relative"
        >
          <Inbox size={20} />
          <small>Mesajlar</small>
          <Badge
            bg="danger"
            pill
            className="position-absolute top-0 start-100 translate-middle"
          >
            {messages.filter((m) => !m.read).length}
          </Badge>
        </Button>
        <Button
          variant="link"
          className="text-dark d-flex flex-column align-items-center"
        >
          <Share size={20} />
          <small>Paylaş</small>
        </Button>
        <Button
          variant="link"
          className="text-dark d-flex flex-column align-items-center"
        >
          <Person size={20} />
          <small>Profil</small>
        </Button>
      </Navbar>

      {/* Yeni Mesaj Modalı */}
      <Modal
        show={showComposeModal}
        onHide={() => setShowComposeModal(false)}
        size="lg"
        centered
      >
        <Modal.Header closeButton className="border-bottom-0 pb-0">
          <Modal.Title>Yeni Mesaj</Modal.Title>
        </Modal.Header>
        <Modal.Body className="pt-0">
          <Form>
            <Form.Group className="mb-3">
              <Form.Label className="fw-bold">Alıcı</Form.Label>
              <div className="d-flex flex-wrap gap-2 mb-2">
                {selectedUsers.map((userId) => {
                  const user = users.find((u) => u.id === userId);
                  return (
                    <Badge
                      key={userId}
                      bg="light"
                      className="d-flex align-items-center text-dark p-2"
                    >
                      <Image
                        src={user.avatar}
                        roundedCircle
                        width={24}
                        height={24}
                        className="me-2"
                      />
                      {user.name}
                      <Button
                        variant="link"
                        className="p-0 ms-2 text-muted"
                        onClick={() => toggleUserSelection(userId)}
                      >
                        <X size={12} />
                      </Button>
                    </Badge>
                  );
                })}
              </div>
              <Button
                variant="outline-secondary"
                size="sm"
                onClick={() => setShowUserList(true)}
              >
                <People size={14} className="me-1" />
                Kişi seç
              </Button>
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label className="fw-bold">Konu</Form.Label>
              <Form.Control type="text" placeholder="Mesaj konusu" />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label className="fw-bold">Mesaj</Form.Label>
              <Form.Control
                as="textarea"
                rows={8}
                placeholder="Mesajınızı buraya yazın..."
              />
            </Form.Group>

            <Accordion className="mb-3">
              <Accordion.Item eventKey="0">
                <Accordion.Header>
                  <Paperclip className="me-2" />
                  Ekler (isteğe bağlı)
                </Accordion.Header>
                <Accordion.Body>
                  <div className="border rounded p-4 text-center bg-light">
                    <div className="py-3">
                      <Paperclip size={32} className="mb-3 text-muted" />
                      <p className="text-muted mb-3">
                        Dosyaları buraya sürükleyip bırakın veya
                      </p>
                      <Button variant="outline-primary">Dosya Seç</Button>
                      <p className="small text-muted mt-3">
                        PDF, JPG, PNG formatlarında, max 10MB
                      </p>
                    </div>
                  </div>
                </Accordion.Body>
              </Accordion.Item>
            </Accordion>
          </Form>
        </Modal.Body>
        <Modal.Footer className="border-top-0">
          <Button
            variant="outline-secondary"
            onClick={() => setShowComposeModal(false)}
          >
            İptal
          </Button>
          <Button variant="primary" onClick={() => setShowComposeModal(false)}>
            <Send className="me-2" />
            Gönder
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Silme Bildirimi */}
      <ToastContainer position="bottom-end" className="p-3">
        <Toast
          show={showDeleteToast}
          onClose={() => setShowDeleteToast(false)}
          delay={5000}
          autohide
          bg="danger"
          className="text-white"
        >
          <Toast.Header closeButton={false} className="bg-danger text-white">
            <strong className="me-auto">
              <Trash className="me-2" />
              Mesaj Silindi
            </strong>
            <Button
              variant="white"
              size="sm"
              className="text-danger p-0"
              onClick={() => setShowDeleteToast(false)}
            >
              <X size={20} />
            </Button>
          </Toast.Header>
          <Toast.Body>
            <div className="d-flex align-items-center">
              <CheckCircle size={24} className="me-2 flex-shrink-0" />
              <div>
                <strong>{deletedMessage?.subject}</strong> başlıklı mesaj
                silindi.
                <div className="d-flex mt-2">
                  <Button
                    variant="outline-light"
                    size="sm"
                    className="me-2"
                    onClick={() => setShowDeleteToast(false)}
                  >
                    Tamam
                  </Button>
                  <Button variant="light" size="sm" className="text-danger">
                    Geri Al
                  </Button>
                </div>
              </div>
            </div>
          </Toast.Body>
        </Toast>
      </ToastContainer>

      {/* CSS */}
      <style>{`
        .message-list {
          --bs-list-group-border-width: 0;
        }
        .message-item {
          transition: all 0.2s ease;
          border-left: 3px solid transparent;
        }
        .message-item:hover, .message-item.active {
          background-color: #f8f9fa !important;
          border-left-color: #0d6efd;
        }
        .message-item.unread {
          background-color: #f0f7ff;
        }
        .message-item.pinned {
          background-color: #fff8e6;
        }
        .message-pin {
          transition: opacity 0.2s ease;
        }
        .message-item:hover .message-pin {
          opacity: 1 !important;
        }
        .badge-dot {
          display: inline-block;
          width: 8px;
          height: 8px;
          border-radius: 50%;
        }
        .hover-primary:hover {
          color: #0d6efd !important;
        }
      `}</style>
    </div>
  );
};

export default InboxPage;
