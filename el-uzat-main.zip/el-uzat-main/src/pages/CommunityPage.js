import React, { useState } from "react";
import {
  Container,
  Button,
  Image,
  Card,
  ListGroup,
  Navbar,
  Form,
  Tab,
  Tabs,
  Stack,
  Badge,
} from "react-bootstrap";
import {
  ChevronLeft,
  Search,
  People,
  Gift,
  Chat,
  ArrowUpRight,
  Heart,
  GeoAlt,
  Plus,
  ArrowRight,
  PersonCircle,
  Envelope,
  BoxSeam,
  Star,
} from "react-bootstrap-icons";

const CommunityPage = () => {
  const [activeTab, setActiveTab] = useState("members");
  const [radius, setRadius] = useState(20);
  const [selectedMember, setSelectedMember] = useState(null);

  // Topluluk verileri
  const community = {
    name: "Ashburn",
    members: 13249,
    radius: radius,
    stats: {
      gifts: 56,
      asks: 8,
      gratitudes: 0,
      connections: 109,
    },
    builder: {
      name: "Heather J (Lakelands)",
      posts: 23,
      raves: 1,
      bio: "Komşuları bir araya getirme ve yerel destek ağları oluşturma tutkusu olan bir topluluk yöneticisi.",
    },
    membersList: [
      {
        name: "Ashley Willy",
        location: "Fairfax",
        posts: 12,
        active: "2 gün önce",
        bio: "Merhaba, ben Ashley. Bahçıvanlık yapmayı ve komşulara ev projelerinde yardım etmeyi seviyorum.",
      },
      {
        name: "Katherine Perry",
        location: "McLean",
        posts: 5,
        active: "1 hafta önce",
        bio: "Bölgeye yeni taşındım ve dost canlısı komşularla tanışmak istiyorum.",
      },
      {
        name: "Austin Ashe",
        location: "Fairfax",
        posts: 28,
        active: "Bugün",
        bio: "Küçük tamiratlar ve tavsiyeler konusunda yardımcı olmaktan mutluluk duyan yerel bir tamirci.",
      },
      {
        name: "Ati Ka",
        location: "Manassas",
        posts: 3,
        active: "3 hafta önce",
        bio: "Yemek sever ve ara sıra komşularla ekstra yemekler paylaşan bir fırıncı.",
      },
      {
        name: "Louise Sperry",
        location: "Cascades",
        posts: 45,
        active: "Dün",
        bio: "Emekli öğretmen, ders verme ve kitap önerileri sunuyor.",
      },
      {
        name: "Nancy Sanchez",
        location: "Gainesville",
        posts: 7,
        active: "4 gün önce",
        bio: "Merhaba, ben Nancy Sanchez. Topluluğumla bağlantı kurmayı seviyorum.",
      },
      {
        name: "Elizabeth Dinuzzo",
        location: "Bristow",
        posts: 19,
        active: "1 gün önce",
        bio: "Yerel aileleri desteklemeye inanan çalışan bir anne.",
      },
      {
        name: "Jamie D'Andrea",
        location: "Ashburn",
        posts: 32,
        active: "Bugün",
        bio: "Yürüyüş grupları organize eden bir fitness tutkunu.",
      },
    ],
  };

  const handleMemberClick = (member) => {
    setSelectedMember(member);
  };

  const handleBackToList = () => {
    setSelectedMember(null);
  };

  return (
    <div className="bg-light" style={{ minHeight: "100vh" }}>
      {/* Üst Navigasyon */}
      <Navbar bg="white" className="border-bottom sticky-top shadow-sm">
        <Container>
          <Button
            variant="link"
            className="p-0 me-2"
            onClick={selectedMember ? handleBackToList : null}
          >
            <ChevronLeft size={20} />
          </Button>
          <Navbar.Brand className="fw-bold">
            {selectedMember ? selectedMember.name : "Topluluğum"}
          </Navbar.Brand>
          <div className="ms-auto">
            <Button variant="link" className="p-0 text-dark">
              <Search size={20} />
            </Button>
          </div>
        </Container>
      </Navbar>

      <Container className="py-3">
        {!selectedMember ? (
          <>
            {/* Topluluk Başlığı */}
            <Card className="border-0 shadow-sm mb-4 overflow-hidden">
              <Card.Body className="p-4">
                <div className="d-flex justify-content-between align-items-center mb-3">
                  <Stack direction="horizontal" gap={2}>
                    <GeoAlt className="text-success mt-1" />
                    <div>
                      <h4 className="mb-0">{community.name}</h4>
                      <div className="d-flex align-items-center text-muted small">
                        <People className="me-1" size={14} />
                        <span>
                          {community.members.toLocaleString()} üye •{" "}
                          {community.radius} km çapında
                        </span>
                      </div>
                    </div>
                  </Stack>
                  <Button
                    variant="outline-success"
                    size="sm"
                    className="rounded-pill"
                  >
                    Değiştir
                  </Button>
                </div>

                <Form.Range
                  value={radius}
                  onChange={(e) => setRadius(e.target.value)}
                  min="1"
                  max="50"
                  className="mb-4"
                />

                <h6 className="text-muted text-uppercase small mb-3">
                  Son 7 Gün
                </h6>
                <div className="row text-center g-3">
                  <div className="col">
                    <div className="fs-4 fw-bold text-success">
                      {community.stats.gifts}
                    </div>
                    <small className="text-muted">İyilik</small>
                  </div>
                  <div className="col">
                    <div className="fs-4 fw-bold text-primary">
                      {community.stats.asks}
                    </div>
                    <small className="text-muted">Talep</small>
                  </div>
                  <div className="col">
                    <div className="fs-4 fw-bold text-warning">
                      {community.stats.gratitudes}
                    </div>
                    <small className="text-muted">Teşekkür</small>
                  </div>
                  <div className="col">
                    <div className="fs-4 fw-bold text-info">
                      {community.stats.connections}
                    </div>
                    <small className="text-muted">Bağlantı</small>
                  </div>
                </div>
              </Card.Body>
            </Card>

            {/* Topluluk Yöneticisi */}
            <Card className="border-0 shadow-sm mb-4" bg="light">
              <Card.Body className="p-4">
                <h5 className="mb-3">Yakındaki Topluluk Yöneticisi</h5>
                <div className="d-flex align-items-center mb-3">
                  <Image
                    src="https://randomuser.me/api/portraits/women/44.jpg"
                    roundedCircle
                    width={60}
                    height={60}
                    className="me-3"
                  />
                  <div>
                    <h6 className="mb-1">{community.builder.name}</h6>
                    <small className="text-muted">
                      {community.builder.posts} gönderi •{" "}
                      {community.builder.raves} takdir
                    </small>
                  </div>
                </div>
                <p className="mb-0 text-muted">
                  <small>
                    "Merhaba ve hoş geldiniz! Burası topluluğunuzun ekranıdır.
                    Topluluk etkinliklerinizi ve etkinizi takip edebilir,
                    çevrenizdeki komşuları bulabilirsiniz."
                  </small>
                </p>
              </Card.Body>
            </Card>

            {/* Hızlı Eylemler */}
            <div className="d-flex justify-content-between mb-4 gap-3">
              <Button
                variant="success"
                className="flex-grow-1 rounded-pill py-2 d-flex align-items-center justify-content-center"
              >
                <Plus size={18} className="me-2" /> Arkadaş Davet Et
              </Button>
              <Button
                variant="outline-success"
                className="flex-grow-1 rounded-pill py-2 d-flex align-items-center justify-content-center"
              >
                <Search size={18} className="me-2" /> Üye Bul
              </Button>
            </div>

            {/* Sekmeler */}
            <Tabs
              activeKey={activeTab}
              onSelect={(k) => setActiveTab(k)}
              className="mb-3 nav-pills"
              fill
            >
              <Tab eventKey="members" title="Üyeler" />
              <Tab eventKey="activity" title="Aktivite" />
              <Tab eventKey="map" title="Harita" />
            </Tabs>

            {/* Üyeler Listesi */}
            {activeTab === "members" && (
              <Card className="border-0 shadow-sm">
                <Card.Body className="p-0">
                  <div className="d-flex justify-content-between align-items-center p-3 border-bottom">
                    <h6 className="mb-0">Topluluğunuzdaki İnsanlar</h6>
                    <small className="text-muted">Son katılanlar</small>
                  </div>

                  <ListGroup variant="flush">
                    {community.membersList.map((member, index) => (
                      <ListGroup.Item
                        key={index}
                        action
                        onClick={() => handleMemberClick(member)}
                        className="px-3 py-3"
                      >
                        <div className="d-flex align-items-center">
                          <div className="me-3">
                            <PersonCircle
                              size={40}
                              className="text-secondary"
                            />
                          </div>
                          <div>
                            <h6 className="mb-0">
                              {member.name}{" "}
                              <small className="text-muted">
                                ({member.location})
                              </small>
                            </h6>
                            <small className="text-muted">
                              {member.posts} gönderi • Son aktivite:{" "}
                              {member.active}
                            </small>
                          </div>
                        </div>
                      </ListGroup.Item>
                    ))}
                  </ListGroup>

                  <Button
                    variant="light"
                    className="w-100 rounded-0 py-3 text-success border-top"
                  >
                    Daha Fazla Göster <ArrowRight className="ms-2" />
                  </Button>
                </Card.Body>
              </Card>
            )}

            {/* Aktivite Sekmesi */}
            {activeTab === "activity" && (
              <div className="text-center py-5">
                <div className="bg-light rounded-circle d-inline-flex p-4 mb-4">
                  <Gift size={40} className="text-muted" />
                </div>
                <h5>Henüz Aktiviteniz Yok</h5>
                <p className="text-muted mb-3">
                  Topluluğunuzdaki son aktiviteler burada görünecek
                </p>
                <Button variant="success" className="rounded-pill px-4">
                  Yeni Gönderi Paylaş
                </Button>
              </div>
            )}

            {/* Harita Sekmesi */}
            {activeTab === "map" && (
              <Card className="border-0 shadow-sm">
                <Card.Body className="text-center py-5">
                  <div className="bg-light rounded-circle d-inline-flex p-4 mb-4">
                    <GeoAlt size={40} className="text-muted" />
                  </div>
                  <h5>Harita Görünümü</h5>
                  <p className="text-muted">
                    Yakınınızdaki topluluk üyelerini haritada görün
                  </p>
                  <Button variant="success" className="rounded-pill px-4">
                    Haritayı Aç
                  </Button>
                </Card.Body>
              </Card>
            )}
          </>
        ) : (
          /* Üye Profil Sayfası */
          <div className="animate__animated animate__fadeIn">
            <Card className="border-0 shadow-sm mb-4 overflow-hidden">
              <Card.Body className="text-center p-4">
                <PersonCircle size={80} className="text-secondary mb-3" />
                <h4>Merhaba, Ben {selectedMember.name}</h4>
                <p className="text-muted mb-4">{selectedMember.bio}</p>

                <div className="d-flex justify-content-center gap-3 mb-4">
                  <Button variant="outline-primary" className="rounded-pill">
                    <Envelope className="me-2" /> Özel Mesaj
                  </Button>
                  <Button variant="outline-success" className="rounded-pill">
                    <BoxSeam className="me-2" /> Hediye Gönder
                  </Button>
                </div>

                <Button variant="outline-warning" className="rounded-pill">
                  <Star className="me-2" /> {selectedMember.name.split(" ")[0]}{" "}
                  hakkında ilk yorumu yap
                </Button>
              </Card.Body>
            </Card>

            <Card className="border-0 shadow-sm mb-4">
              <Card.Body>
                <h6 className="mb-3">Topluluk: {selectedMember.location}</h6>
                <div className="d-flex align-items-center text-muted small mb-3">
                  <span className="me-2">Gönderiler</span>
                  <Badge bg="light" text="dark" className="rounded-pill">
                    {selectedMember.posts}
                  </Badge>
                  <span className="mx-2">•</span>
                  <span>Aktif: {selectedMember.active}</span>
                </div>

                <div className="d-flex border-top pt-3">
                  <Button variant="link" className="text-muted me-3">
                    <Stack
                      direction="vertical"
                      gap={1}
                      className="align-items-center"
                    >
                      <Gift size={20} />
                      <small>Hediyeler</small>
                    </Stack>
                  </Button>
                  <Button variant="link" className="text-muted me-3">
                    <Stack
                      direction="vertical"
                      gap={1}
                      className="align-items-center"
                    >
                      <Chat size={20} />
                      <small>Gönderiler</small>
                    </Stack>
                  </Button>
                  <Button variant="link" className="text-muted">
                    <Stack
                      direction="vertical"
                      gap={1}
                      className="align-items-center"
                    >
                      <Heart size={20} />
                      <small>Beğeniler</small>
                    </Stack>
                  </Button>
                </div>
              </Card.Body>
            </Card>

            <Card className="border-0 shadow-sm">
              <Card.Body className="text-center py-4">
                <h5 className="mb-3">Son Aktivite</h5>
                <div className="bg-light rounded-circle d-inline-flex p-4 mb-3">
                  <Gift size={40} className="text-muted" />
                </div>
                <p className="text-muted">Henüz aktivite yok</p>
                <Button variant="outline-success" className="rounded-pill">
                  Tüm geçmişi gör
                </Button>
              </Card.Body>
            </Card>
          </div>
        )}
      </Container>

      {/* CSS Stilleri */}
      <style>{`
        .nav-pills .nav-link {
          border-radius: 20px;
          color: #495057;
          font-weight: 500;
          padding: 0.5rem 1rem;
          margin: 0 2px;
          transition: all 0.2s;
          border: none;
        }
.nav-pills .nav-link.active {
  background-color: transparent;
  color: inherit; /* Mevcut metin rengini kullanır */
  border-bottom: 2px solid black; /* Altı çizili görünüm */
  border-radius: 0; /* İstersen köşeleri köşeli yapar */
}

        .nav-pills .nav-link:hover:not(.active) {
          background-color: rgba(40, 167, 69, 0.1);
        }
        .animate__animated {
          animation-duration: 0.3s;
        }
      `}</style>
    </div>
  );
};

export default CommunityPage;
