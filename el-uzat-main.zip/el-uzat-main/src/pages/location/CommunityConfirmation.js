import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Container, 
  Form, 
  Button, 
  Card, 
  FloatingLabel,
  Alert
} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';

const CommunityNamingPage = () => {
  const [neighborhood, setNeighborhood] = useState('');
  const navigate = useNavigate();
  
  const handleSubmit = (e) => {
    e.preventDefault();
    navigate('/community-confirmation', {
      state: {
        community: neighborhood,
        username: "hacker tiem"
      }
    });
  };

  return (
    <div className="d-flex flex-column vh-100 bg-light">
      {/* Header */}
      <div className="text-center py-4 bg-white shadow-sm">
        <Container>
          <Button 
            variant="link" 
            className="position-absolute start-0 ms-3 text-success"
            onClick={() => navigate(-1)}
          >
            <i className="bi bi-arrow-left fs-4"></i>
          </Button>
          <h5 className="m-0 fw-bold text-dark">Topluluk Adını Belirle</h5>
        </Container>
      </div>

      {/* Main Content */}
      <main className="flex-grow-1 overflow-auto py-4">
        <Container className="px-4">
          <Card className="border-0 shadow-sm">
            <Card.Body className="p-4">
              <Form onSubmit={handleSubmit}>
                <FloatingLabel
                  controlId="neighborhoodInput"
                  label={
                    <span className="d-flex align-items-center">
                      <i className="bi bi-geo-alt-fill me-2 text-success"></i>
                      Mahalle/Çevre adı
                    </span>
                  }
                  className="mb-4"
                >
                  <Form.Control
                    type="text"
                    value={neighborhood}
                    onChange={(e) => setNeighborhood(e.target.value)}
                    placeholder="Örnek: Dulles, Beşiktaş"
                    className="py-3 ps-5 border-0"
                    required
                  />
                </FloatingLabel>

                <div className="mb-4">
                  <h6 className="fw-bold mb-3">Profilinizde şu şekilde görünecek:</h6>
                  <div className="d-flex align-items-center bg-light rounded p-3">
                    <div className="bg-success bg-opacity-10 rounded-circle p-2 me-3">
                      <i className="bi bi-person-fill fs-5 text-success"></i>
                    </div>
                    <div>
                      <h5 className="mb-0 fw-bold">hacker tiem • {neighborhood || '[Mahalle]'}</h5>
                    </div>
                  </div>
                  <Alert variant="info" className="mt-2 small">
                    <i className="bi bi-info-circle me-2"></i>
                    Bu bilgi profil sayfanızda görünecektir
                  </Alert>
                </div>

                <Button 
                  variant="success" 
                  type="submit" 
                  className="w-100 py-3 fw-bold"
                  disabled={!neighborhood.trim()}
                >
                  <i className="bi bi-check2-circle me-2"></i>
                  Onayla
                </Button>
              </Form>
            </Card.Body>
          </Card>
        </Container>
      </main>

      {/* Footer */}
      <footer className="bg-white border-top py-3">
        <Container className="text-center">
          <small className="text-muted d-flex align-items-center justify-content-center">
            <i className="bi bi-shield-lock me-2 text-success"></i>
            Bilgileriniz güvende tutulur
          </small>
        </Container>
      </footer>
    </div>
  );
};

export default CommunityNamingPage;