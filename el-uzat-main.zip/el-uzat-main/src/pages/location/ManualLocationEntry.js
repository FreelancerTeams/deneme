import React, { useState, useEffect } from 'react';
import { 
  Button, 
  Container, 
  Form, 
  FloatingLabel, 
  Card, 
  Spinner,
  Alert
} from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';

const ManualLocationEntry = () => {
  const [address, setAddress] = useState('');
  const [showMap, setShowMap] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isValidAddress, setIsValidAddress] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const delayDebounce = setTimeout(() => {
      if (address.length > 3) {
        setIsLoading(true);
        // Simulate API call
        setTimeout(() => {
          setShowMap(true);
          setIsValidAddress(address.length > 10);
          setIsLoading(false);
        }, 800);
      } else {
        setShowMap(false);
        setIsValidAddress(false);
      }
    }, 500);

    return () => clearTimeout(delayDebounce);
  }, [address]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isValidAddress) {
      console.log("Location confirmed:", address);
      // Handle successful submission
      navigate('/'); // Or wherever you want to redirect after submission
    }
  };

  return (
    <div className="d-flex flex-column vh-100 bg-light">
      {/* Header */}
      <div className="text-center py-4 bg-white shadow-sm">
        <Container>
          <Button 
            variant="link" 
            className="position-absolute start-0 ms-3 text-success"
            onClick={() => navigate(-1)}
          >
            <i className="bi bi-arrow-left fs-4"></i>
          </Button>
          <h5 className="m-0 fw-bold text-dark">Konumunuzu Belirleyin</h5>
        </Container>
      </div>

      {/* Main Content */}
      <main className="flex-grow-1 overflow-auto py-4">
        <Container className="px-4">
          {/* Search Card */}
          <Card className="border-0 shadow-sm mb-4">
            <Card.Body className="p-4">
              <Form onSubmit={handleSubmit}>
                <FloatingLabel
                  controlId="addressInput"
                  label={
                    <span className="d-flex align-items-center">
                      <i className="bi bi-geo-alt-fill me-2 text-success"></i>
                      Adresinizi yazın
                    </span>
                  }
                >
                  <Form.Control
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Örnek: Atatürk Caddesi No:10, Beşiktaş"
                    className="py-3 ps-5 border-0"
                  />
                </FloatingLabel>
              </Form>
            </Card.Body>
          </Card>

          {/* Loading State */}
          {isLoading && (
            <div className="text-center my-5">
              <Spinner animation="border" variant="success" />
              <p className="mt-3 text-muted">Konum aranıyor...</p>
            </div>
          )}

          {/* Map Preview */}
          {showMap && !isLoading && (
            <Card className="border-0 shadow-sm overflow-hidden mb-4">
              <div 
                className="w-100 bg-light" 
                style={{ height: '250px' }}
              >
                <div className="w-100 h-100 d-flex align-items-center justify-content-center">
                  <div className="text-center p-4">
                    <div className="bg-success bg-opacity-10 rounded-circle p-4 d-inline-block mb-3">
                      <i className="bi bi-geo-alt fs-2 text-success"></i>
                    </div>
                    <h5 className="mt-2 fw-bold">{address}</h5>
                    <p className="text-muted">Harita önizleme alanı</p>
                  </div>
                </div>
              </div>
              <Card.Footer className="bg-white border-0 p-0">
                <Button 
                  variant="success" 
                  size="lg" 
                  className="w-100 rounded-0 py-3 fw-bold"
                  disabled={!isValidAddress}
                  onClick={handleSubmit}
                >
                  <i className="bi bi-check-circle me-2"></i>
                  Konumu Onayla
                </Button>
                {!isValidAddress && (
                  <Alert variant="danger" className="mb-0 rounded-0 small">
                    Lütfen geçerli bir adres giriniz
                  </Alert>
                )}
              </Card.Footer>
            </Card>
          )}

          {/* Empty State */}
          {!showMap && !isLoading && (
            <Card className="border-0 shadow-sm text-center py-5">
              <Card.Body>
                <div className="bg-success bg-opacity-10 rounded-circle p-4 d-inline-block">
                  <i className="bi bi-map fs-2 text-success"></i>
                </div>
                <h5 className="mt-3 text-dark">Adresinizi girin</h5>
                <p className="text-muted">
                  Arama yapmak için yukarıya adres bilgilerinizi giriniz
                </p>
              </Card.Body>
            </Card>
          )}
        </Container>
      </main>

      {/* Footer */}
      <footer className="bg-white border-top py-3">
        <Container className="text-center">
          <small className="text-muted d-flex align-items-center justify-content-center">
            <i className="bi bi-shield-lock me-2 text-success"></i>
            Konum bilgileriniz güvende tutulur
          </small>
        </Container>
      </footer>
    </div>
  );
};

export default ManualLocationEntry;