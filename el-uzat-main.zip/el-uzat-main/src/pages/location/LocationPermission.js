import React from "react";
import { Button, Container } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import { useNavigate } from "react-router-dom";

const LocationPermission = () => {
  const navigate = useNavigate();
  const handleGPSLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => console.log("Konum alındı:", position),
        (error) => console.error("Konum hatası:", error),
        { enableHighAccuracy: true }
      );
    } else {
      alert("Tarayıcınız konum servislerini desteklemiyor.");
    }
  };

  const handleManualEntry = () => {
    console.log("Manuel giriş seçildi");
    navigate("/manual-entry");
  };

  return (
    <div className="vh-100 d-flex flex-column bg-light">
      {/* Logo ve Başlık */}
      <div className="text-center py-5">
        <img
          src="/logo.png"
          alt="El Uzat Logo"
          className="mb-3"
          style={{ height: "80px" }}
        />
        <h1 className="display-5 fw-bold text-dark">El Uzat</h1>
        <p className="text-muted">Topluluk Dayanışma Platformu</p>
      </div>

      {/* Ana İçerik */}
      <div className="flex-grow-1 d-flex flex-column px-3">
        <Container className="my-auto">
          <div className="text-center mb-5">
            <div
              className="d-inline-flex align-items-center justify-content-center mb-4 bg-success 
              rounded-circle p-4 shadow-sm"
              style={{ width: "100px", height: "100px" }}
            >
              <i className="bi bi-geo-alt fs-1 text-white"></i>
            </div>
            <h2 className="fw-bold mb-3 text-dark">Mahallenizi Keşfedin</h2>
            <p
              className="text-muted fs-5 mx-auto"
              style={{ maxWidth: "600px" }}
            >
              Yakınınızdaki yardım taleplerini gösterebilmek için konum
              erişimine izin verin.
            </p>
          </div>

          {/* Tam genişlik butonlar */}
          <div className="d-grid gap-3 w-100">
            <Button
              variant="success"
              size="lg"
              onClick={handleGPSLocation}
              className="py-3 fw-bold rounded-pill"
            >
              <i className="bi bi-geo-alt-fill me-2"></i>
              KONUM PAYLAŞ
            </Button>

            <Button
              variant="outline-success"
              size="lg"
              onClick={handleManualEntry}
              className="py-3 rounded-pill fw-bold"
            >
              <i className="bi bi-pencil-square me-2"></i>
              MANUEL GİRİŞ
            </Button>
          </div>
        </Container>
      </div>

      {/* Footer */}
      <div className="py-3 text-center text-muted">
        <p className="mb-0 small">© {new Date().getFullYear()} El Uzat</p>
      </div>
    </div>
  );
};

export default LocationPermission;
