import React, { useState } from "react";
import {
  Modal,
  Image,
  Button,
  Form,
  Badge,
  Container,
  Row,
  Col,
  ListGroup,
  Stack,
  Dropdown,
} from "react-bootstrap";
import {
  Heart,
  HeartFill,
  Bookmark,
  BookmarkFill,
  Chat,
  Gift,
  GeoAlt,
  ThreeDots,
  X,
  ArrowLeft,
  Share,
} from "react-bootstrap-icons";

const PostDetailModal = ({ post, show, onHide, onLike, onSave, onComment }) => {
  const [commentText, setCommentText] = useState("");
  const [showFullImage, setShowFullImage] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const handleCommentSubmit = (e) => {
    e.preventDefault();
    if (commentText.trim()) {
      onComment(post.id, commentText);
      setCommentText("");
    }
  };

  const handleImageClick = (index) => {
    setCurrentImageIndex(index);
    setShowFullImage(true);
  };

  const navigateImage = (direction) => {
    const newIndex = direction === "prev" 
      ? (currentImageIndex - 1 + post.images.length) % post.images.length
      : (currentImageIndex + 1) % post.images.length;
    setCurrentImageIndex(newIndex);
  };

  return (
    <>
      {/* Main Post Detail Modal */}
      <Modal
        show={show}
        onHide={onHide}
        fullscreen="md-down"
        centered
        className="post-detail-modal"
      >
        <Modal.Header className="border-0 position-relative">
          <Button
            variant="link"
            onClick={onHide}
            className="position-absolute start-0 ms-3 p-0 text-dark"
          >
            <ArrowLeft size={24} />
          </Button>
          <Modal.Title className="mx-auto">Gönderi Detayları</Modal.Title>
        </Modal.Header>

        <Modal.Body className="p-0">
          {/* Post Content */}
          <div className="px-3 pb-3">
            {/* User Info */}
            <div className="d-flex align-items-center mb-3">
              <Image
                src={post.avatar}
                roundedCircle
                width={48}
                height={48}
                className="me-2"
              />
              <div>
                <div className="fw-bold">{post.user}</div>
                <small className="text-muted">{post.time}</small>
              </div>
              <Dropdown className="ms-auto">
                <Dropdown.Toggle variant="link" className="text-dark p-0">
                  <ThreeDots size={20} />
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  <Dropdown.Item onClick={() => onSave(post.id)}>
                    {post.saved ? (
                      <>
                        <BookmarkFill className="me-2 text-success" />
                        Kaydedilenlerden çıkar
                      </>
                    ) : (
                      <>
                        <Bookmark className="me-2" />
                        Kaydet
                      </>
                    )}
                  </Dropdown.Item>
                  <Dropdown.Item>
                    <Share className="me-2" />
                    Paylaş
                  </Dropdown.Item>
                  <Dropdown.Divider />
                  <Dropdown.Item className="text-danger">
                    <X className="me-2" />
                    Bildir
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </div>

            {/* Post Text */}
            <div className="mb-3">
              <h5>{post.title}</h5>
              <p>{post.content}</p>
            </div>

            {/* Location */}
            <div className="d-flex align-items-center mb-3">
              <GeoAlt className="me-2 text-success" />
              <span className="text-muted">{post.location}</span>
            </div>

            {/* Images - Thumbnail View */}
            {post.images.length > 0 && (
              <div className="mb-3">
                <Row xs={3} className="g-2">
                  {post.images.map((img, index) => (
                    <Col key={index}>
                      <div 
                        className="ratio ratio-1x1 bg-light rounded"
                        style={{ cursor: "pointer" }}
                        onClick={() => handleImageClick(index)}
                      >
                        <Image
                          src={img}
                          alt={`Post image ${index + 1}`}
                          className="w-100 h-100 object-fit-cover rounded"
                        />
                      </div>
                    </Col>
                  ))}
                </Row>
              </div>
            )}

            {/* Action Buttons */}
            <div className="d-flex justify-content-between border-top border-bottom py-2 mb-3">
              <Button
                variant="link"
                className={`text-decoration-none p-0 ${post.liked ? "text-danger" : "text-dark"}`}
                onClick={() => onLike(post.id)}
              >
                {post.liked ? (
                  <HeartFill size={20} className="me-1" />
                ) : (
                  <Heart size={20} className="me-1" />
                )}
                <span>{post.likes}</span>
              </Button>

              <Button variant="link" className="text-decoration-none p-0 text-dark">
                <Chat size={20} className="me-1" />
                <span>{post.comments.length}</span>
              </Button>

              <Button variant="link" className="text-decoration-none p-0 text-dark">
                <Gift size={20} className="me-1" />
              </Button>
            </div>

            {/* Interest Button */}
            <Button variant="success" className="w-100 mb-4">
              {post.type === "yardim" ? "İlgileniyorum" : "Yardım Edebilirim"}
            </Button>
          </div>

          {/* Comments Section */}
          <div className="bg-light p-3">
            <h6 className="fw-bold mb-3">Yorumlar ({post.comments.length})</h6>

            {post.comments.length > 0 ? (
              <ListGroup variant="flush" className="mb-3">
                {post.comments.map((comment) => (
                  <ListGroup.Item key={comment.id} className="px-0 bg-transparent">
                    <div className="d-flex">
                      <Image
                        src={comment.avatar}
                        roundedCircle
                        width={36}
                        height={36}
                        className="me-2 flex-shrink-0"
                      />
                      <div>
                        <div className="fw-bold">{comment.user}</div>
                        <div className="small text-muted mb-1">{comment.time}</div>
                        <div>{comment.content}</div>
                      </div>
                    </div>
                  </ListGroup.Item>
                ))}
              </ListGroup>
            ) : (
              <div className="text-center py-4 text-muted">
                Henüz yorum yok, ilk yorumu sen yap!
              </div>
            )}

            {/* Comment Form */}
            <Form onSubmit={handleCommentSubmit}>
              <Stack direction="horizontal" gap={2}>
                <Form.Control
                  type="text"
                  placeholder="Bir yorum ekle..."
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                />
                <Button
                  variant="success"
                  type="submit"
                  disabled={!commentText.trim()}
                >
                  Gönder
                </Button>
              </Stack>
            </Form>
          </div>
        </Modal.Body>
      </Modal>

      {/* Full Image View Modal */}
      <Modal
        show={showFullImage}
        onHide={() => setShowFullImage(false)}
        centered
        size="lg"
        className="image-modal"
        fullscreen="md-down"
      >
        <Modal.Header className="border-0 position-absolute top-0 end-0 z-1">
          <Button
            variant="link"
            onClick={() => setShowFullImage(false)}
            className="text-white p-0"
          >
            <X size={24} />
          </Button>
        </Modal.Header>
        
        <Modal.Body className="p-0 d-flex align-items-center justify-content-center bg-dark">
          <Image
            src={post.images[currentImageIndex]}
            fluid
            style={{ maxHeight: "80vh", objectFit: "contain" }}
          />
          
          {post.images.length > 1 && (
            <>
              <Button
                variant="link"
                className="position-absolute start-0 top-50 translate-middle-y text-white p-3"
                onClick={() => navigateImage("prev")}
              >
                <ChevronLeft size={32} />
              </Button>
              <Button
                variant="link"
                className="position-absolute end-0 top-50 translate-middle-y text-white p-3"
                onClick={() => navigateImage("next")}
              >
                <ChevronRight size={32} />
              </Button>
              
              <div className="position-absolute bottom-0 start-50 translate-middle-x mb-3">
                <div className="d-flex">
                  {post.images.map((_, index) => (
                    <div
                      key={index}
                      className={`mx-1 rounded-circle ${index === currentImageIndex ? "bg-white" : "bg-white bg-opacity-50"}`}
                      style={{ width: "8px", height: "8px", cursor: "pointer" }}
                      onClick={() => setCurrentImageIndex(index)}
                    />
                  ))}
                </div>
              </div>
            </>
          )}
        </Modal.Body>
      </Modal>
    </>
  );
};

export default PostDetailModal;