import React, { useState, useRef } from 'react';
import { 
  Modal, 
  Form, 
  Button, 
  FormCheck,
  Badge,
  FloatingLabel,
  ProgressBar,
  Image,
  Stack
} from 'react-bootstrap';
import { 
  X, 
  Globe, 
  Truck, 
  PersonCircle,
  Camera,
  ArrowLeft,
  Trash,
  GeoAlt,
  InfoCircle
} from 'react-bootstrap-icons';

const HelpRequestModal = ({ show, onHide }) => {
  const [isGlobal, setIsGlobal] = useState(false);
  const [requestShipping, setRequestShipping] = useState(false);
  const [requestText, setRequestText] = useState('');
  const [location, setLocation] = useState('');
  const [selectedImage, setSelectedImage] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef(null);

  // Modern green theme colors
  const themeColors = {
    primary: '#10B981', // Emerald green
    light: '#D1FAE5',
    dark: '#059669',
    icon: '#10B981'
  };

  const handleSubmit = () => {
    if (!requestText.trim()) {
      return;
    }
    
    console.log({
      requestText,
      isGlobal,
      requestShipping,
      location,
      image: selectedImage
    });
    
    onHide();
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setIsUploading(true);
      setUploadProgress(0);
      
      // Simulate upload progress
      const interval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setIsUploading(false);
            return 100;
          }
          return prev + 10;
        });
      }, 200);
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setSelectedImage(null);
  };

  const triggerFileInput = () => {
    fileInputRef.current.click();
  };

  return (
    <Modal 
      show={show} 
      onHide={onHide} 
      fullscreen 
      centered
      backdrop="static"
      className="modern-request-modal"
    >
      <Modal.Header className="border-0 px-4 pt-3 pb-0">
        <div className="d-flex justify-content-between w-100 align-items-center">
          <Button 
            variant="link" 
            onClick={onHide} 
            className="p-0 text-muted fs-5 close-btn"
          >
            <ArrowLeft size={24} />
          </Button>
          
          <div className="text-center">
            <h4 className="fw-bold" style={{color: themeColors.dark}}>Yardım Talebi Oluştur</h4>
          </div>
          
          <Button 
            variant="success" 
            className="submit-btn px-3 py-1 rounded-3 fw-medium"
            disabled={!requestText.trim()}
            style={{
              backgroundColor: themeColors.primary, 
              borderColor: themeColors.primary,
              minWidth: '80px'
            }}
            onClick={handleSubmit}
          >
            Gönder
          </Button>
        </div>
      </Modal.Header>

      <Modal.Body className="px-4 pb-5">
        {/* User Info */}
        <div className="d-flex align-items-center mb-4">
          <div className="position-relative me-3">
            <PersonCircle className="avatar-icon" size={48} style={{color: themeColors.primary}} />
            <Badge pill bg="success" className="online-badge"></Badge>
          </div>
          <div>
            <div className="fw-bold">Kullanıcı Adı</div>
            <div className="text-muted small">Konum • Şimdi</div>
          </div>
        </div>

        <Form>
          {/* Request Text */}
          <Form.Group className="mb-4">
            <Form.Control
              as="textarea"
              rows={4}
              placeholder="Ne talep etmek istiyorsunuz?"
              className="post-textarea border-0 p-0 fs-5"
              value={requestText}
              onChange={(e) => setRequestText(e.target.value)}
            />
          </Form.Group>

          {/* Image Upload */}
          {selectedImage && (
            <div className="mb-4 position-relative">
              <Image 
                src={selectedImage} 
                alt="Request content" 
                fluid 
                rounded 
                className="w-100"
                style={{ maxHeight: '300px', objectFit: 'cover' }}
              />
              <Button 
                variant="danger" 
                size="sm" 
                className="position-absolute top-0 end-0 m-2 rounded-circle p-2"
                onClick={removeImage}
              >
                <Trash size={16} />
              </Button>
              {isUploading && (
                <ProgressBar 
                  now={uploadProgress} 
                  label={`${uploadProgress}%`} 
                  className="mt-2"
                  variant="success"
                />
              )}
            </div>
          )}

          {/* Location Input */}
          <div className="mb-4">
            <div className="section-label mb-2" style={{color: themeColors.primary}}>
              KONUM BİLGİSİ
            </div>
            <div className="position-relative">
              <GeoAlt className="input-icon" style={{color: themeColors.primary}} />
              <Form.Control
                type="text"
                placeholder="Teslimat adresi veya buluşma noktası"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="location-input py-2 ps-4"
                style={{borderLeft: `2px solid ${themeColors.primary}`}}
              />
            </div>
          </div>

          {/* Options */}
          <div className="mb-3 p-3 rounded-3 option-container" style={{backgroundColor: themeColors.light + '40'}}>
            <FormCheck
              type="switch"
              id="global-visible"
              label={
                <span className="d-flex align-items-center option-item">
                  <Globe className="me-2" size={20} style={{color: themeColors.primary}} />
                  Bu gönderiyi herkese görünür yap
                </span>
              }
              checked={isGlobal}
              onChange={(e) => setIsGlobal(e.target.checked)}
              className="custom-switch"
            />
          </div>

          <div className="mb-4 p-3 rounded-3 option-container" style={{backgroundColor: themeColors.light + '40'}}>
            <FormCheck
              type="switch"
              id="request-shipping"
              label={
                <span className="d-flex align-items-center option-item">
                  <Truck className="me-2" size={20} style={{color: themeColors.primary}} />
                  Kargo ile gönderilmesi için ödeme yapmaya hazırım
                </span>
              }
              checked={requestShipping}
              onChange={(e) => setRequestShipping(e.target.checked)}
              className="custom-switch"
            />
          </div>
        </Form>
        
        {/* Camera Button */}
        <div className="camera-btn-container">
          <label htmlFor="request-image-upload" className="camera-btn-label">
            <Button 
              variant="primary" 
              className="camera-btn rounded-circle"
              style={{backgroundColor: themeColors.primary, borderColor: themeColors.primary}}
            >
              <Camera size={22} />
            </Button>
          </label>
          <input 
            ref={fileInputRef}
            id="request-image-upload"
            type="file" 
            accept="image/*" 
            onChange={handleImageUpload}
            className="d-none"
          />
        </div>
      </Modal.Body>

      <style jsx>{`
        .modern-request-modal {
          font-family: 'Inter', system-ui, sans-serif;
        }
        
        .modern-request-modal .modal-content {
          border-radius: 0;
          border: none;
          min-height: 100vh;
          background-color: #ffffff;
        }
        
        .close-btn {
          color: #6c757d !important;
          font-weight: 500;
        }
        
        .submit-btn {
          color: white !important;
          transition: all 0.2s ease;
          box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3);
        }
        
        .submit-btn:disabled {
          opacity: 0.65;
          background-color: ${themeColors.light} !important;
          border-color: ${themeColors.light} !important;
          box-shadow: none;
        }
        
        .submit-btn:not(:disabled):hover {
          background-color: ${themeColors.dark} !important;
          border-color: ${themeColors.dark} !important;
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4);
        }
        
        .avatar-icon {
          transition: transform 0.2s;
        }
        
        .avatar-icon:hover {
          transform: scale(1.1);
        }
        
        .online-badge {
          position: absolute;
          bottom: 0;
          right: 0;
          width: 12px;
          height: 12px;
          border: 2px solid white;
          background-color: ${themeColors.primary} !important;
        }
        
        .post-textarea {
          font-size: 18px;
          min-height: 160px;
          line-height: 1.6;
          resize: none;
          background-color: transparent;
        }
        
        .post-textarea:focus {
          box-shadow: none;
          outline: none;
        }
        
        .section-label {
          font-size: 0.75rem;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          font-weight: 600;
        }
        
        .option-item {
          color: #495057;
          padding: 8px 0;
          transition: color 0.2s;
        }
        
        .option-item:hover {
          color: ${themeColors.dark};
        }
        
        .input-icon {
          position: absolute;
          top: 12px;
          left: 12px;
          z-index: 1;
        }
        
        .location-input {
          background-color: #f8f9fa;
          border: none;
          border-radius: 8px;
          padding-left: 35px !important;
          transition: all 0.2s;
        }
        
        .location-input:focus {
          background-color: #fff;
          box-shadow: 0 0 0 2px ${themeColors.light};
        }
        
        .camera-btn-container {
          position: fixed;
          bottom: 20px;
          left: 0;
          right: 0;
          display: flex;
          justify-content: center;
          padding: 16px;
          background: linear-gradient(transparent, white 70%);
        }
        
        .camera-btn-label {
          cursor: pointer;
        }
        
        .camera-btn {
          width: 56px;
          height: 56px;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
          transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .camera-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(0, 0, 0, 0.2);
        }

        /* Improved switch styles */
        .custom-switch .form-check-input {
          width: 2.5em;
          height: 1.5em;
          margin-right: 0.5em;
          background-color: #e9ecef;
          border: 1px solid #dee2e6;
        }

        .custom-switch .form-check-input:checked {
          background-color: ${themeColors.primary};
          border-color: ${themeColors.primary};
        }

        .custom-switch .form-check-input:focus {
          box-shadow: 0 0 0 0.25rem rgba(16, 185, 129, 0.25);
        }

        .custom-switch .form-check-label {
          cursor: pointer;
        }

        .option-container {
          transition: all 0.2s ease;
        }

        .option-container:hover {
          background-color: ${themeColors.light + '60'} !important;
        }
      `}</style>
    </Modal>
  );
};

export default HelpRequestModal;