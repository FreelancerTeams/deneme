import React, { useState } from "react";
import {
  Container,
  Row,
  Col,
  Navbar,
  Form,
  Dropdown,
  Button,
  Image,
  Card,
  Tab,
  Tabs,
  ListGroup,
  Badge,
  Modal,
  Stack,
  Offcanvas,
  ButtonGroup,
} from "react-bootstrap";
import {
  Globe,
  PinMap,
  ListUl,
  Send,
  ThreeDots,
  GeoAlt,
  GeoAltFill,
  Search,
  ChevronLeft,
  ChevronRight,
  House,
  Inbox,
  Share,
  Person,
  People,
  Heart,
  Leaf,
  Grid,
  List,
  X,
  InfoCircle,
  Bookmark,
  Gift,
  Chat,
} from "react-bootstrap-icons";
import BottomNav from "../components/BottomNav";
import HelpOfferModal from "./HelpOfferModal";
import HelpRequestModal from "./HelpRequestModal";
import DetailModal from "./DetailModal";

const Home = () => {
  const [activeTab, setActiveTab] = useState("aktif");
  const [showPostModal, setShowPostModal] = useState(false);
  const [postType, setPostType] = useState("yardim");
  const [viewMode, setViewMode] = useState("detailed");
  const [selectedPost, setSelectedPost] = useState(null);
  const [showLocationModal, setShowLocationModal] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [showPostMenu, setShowPostMenu] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState("Kadıköy");
  const [showOfferModal, setShowOfferModal] = useState(false);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [filterType, setFilterType] = useState("all");

  const samplePosts = [
    {
      id: 1,
      user: "Elif Kaya (Kadıköy)",
      avatar: "https://randomuser.me/api/portraits/women/32.jpg",
      time: "9 saat önce",
      images: ["https://images.unsplash.com/photo-1586671267731-da2cf3ceeb80"],
      title: "Bebek salı - iyi durumda, fazladan var!",
      content: "Bebek salımız fazla geldi, iyi durumda ve ücretsiz veriyoruz.",
      type: "yardim",
      location: "George Mason Üniversitesi yakını",
      detailedLocation: "Kadıköy, İstanbul",
      status: "aktif",
      comments: [
        {
          user: "G07",
          content: "1 yaşında bir çocuğum var, kullanabiliriz.",
        },
        {
          user: "Ahmet Y.",
          content: "Hala müsait mi? Yarın alabilirim.",
        },
      ],
      likes: 12,
      saved: false,
    },
    {
      id: 2,
      user: "Mehmet Demir (Beşiktaş)",
      avatar: "https://randomuser.me/api/portraits/men/45.jpg",
      time: "2 gün önce",
      images: ["https://images.unsplash.com/photo-1551232864-3f0890e580d9"],
      title: "Kullanılmamış bebek bezi - 3 numara",
      content: "Fazla aldığım bebek bezlerini ihtiyacı olan ailelere verebilirim.",
      type: "yardim",
      location: "Beşiktaş Meydan",
      detailedLocation: "Beşiktaş, İstanbul",
      status: "aktif",
      comments: [
        {
          user: "Ayşe K.",
          content: "Çok ihtiyacım var, nasıl ulaşabilirim?",
        },
      ],
      likes: 8,
      saved: false,
    },
    {
      id: 3,
      user: "Zeynep Şahin (Üsküdar)",
      avatar: "https://randomuser.me/api/portraits/women/68.jpg",
      time: "1 gün önce",
      images: ["https://images.unsplash.com/photo-1607619056574-7b8d3ee536b2"],
      title: "Çocuk kitapları - hediye",
      content: "5-8 yaş arası çocuklar için hikaye kitaplarım var.",
      type: "yardim",
      location: "Üsküdar Sahil",
      detailedLocation: "Üsküdar, İstanbul",
      status: "aktif",
      comments: [],
      likes: 5,
      saved: false,
    },
    {
      id: 4,
      user: "Can Aydın (Şişli)",
      avatar: "https://randomuser.me/api/portraits/men/32.jpg",
      time: "5 saat önce",
      images: ["https://images.unsplash.com/photo-1584308666744-24d5c474f2ae"],
      title: "Bebek arabası arıyorum",
      content: "İkinci el temiz bir bebek arabası arıyorum, 0-3 yaş için.",
      type: "talep",
      location: "Şişli Metro",
      detailedLocation: "Şişli, İstanbul",
      status: "aktif",
      comments: [
        {
          user: "Deniz T.",
          content: "Benim kullanmadığım bir araba var, fotoğraf atabilirim.",
        },
      ],
      likes: 3,
      saved: false,
    },
  ];

  const handlePostClick = (post) => {
    setSelectedPost(post);
  };

  const toggleSavePost = (postId) => {
    // Implement save functionality
  };

  return (
    <div className="d-flex flex-column min-vh-100" style={{ backgroundColor: "#f8fdf2" }}>
      {/* Top Navigation */}
      <Navbar
        bg="white"
        expand="lg"
        className="border-bottom py-2 px-3 shadow-sm"
      >
        <Container fluid>
          <Navbar.Brand className="d-flex align-items-center">
            <span className="fw-bold me-2 text-success fs-4">El Uzat</span>
            <div
              className="border border-success rounded-pill px-3 py-1"
              style={{ cursor: "pointer" }}
              onClick={() => setShowLocationModal(true)}
            >
              <div className="d-flex align-items-center">
                <span className="text-success fw-medium">
                  {selectedLocation}
                </span>
                <svg
                  width="12"
                  height="12"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="#28a745"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="ms-2"
                >
                  <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
              </div>
            </div>
          </Navbar.Brand>

          <div className="d-flex align-items-center">
            <Button
              variant="outline-success"
              className="rounded-circle p-2 me-2 d-flex align-items-center justify-content-center"
              style={{ width: "36px", height: "36px" }}
              onClick={() => setShowSearch(true)}
            >
              <Search size={18} />
            </Button>
            <Button
              variant="outline-success"
              className="rounded-circle p-2 me-2 d-flex align-items-center justify-content-center"
              style={{ width: "36px", height: "36px" }}
              onClick={() =>
                setViewMode(viewMode === "detailed" ? "grid" : "detailed")
              }
            >
              {viewMode === "detailed" ? (
                <Grid size={18} />
              ) : (
                <List size={18} />
              )}
            </Button>
          </div>
        </Container>
      </Navbar>

      {/* Search Offcanvas */}
      <Offcanvas
        show={showSearch}
        onHide={() => setShowSearch(false)}
        placement="top"
      >
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>Ara</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          <Form.Control
            type="search"
            placeholder="Ne aramak istiyorsunuz?"
            className="mb-3"
          />
          <div className="text-muted small">
            Örneğin: "bebek bezi", "market alışverişi"
          </div>
        </Offcanvas.Body>
      </Offcanvas>

      {/* Location Selection Modal */}
      <Modal
        show={showLocationModal}
        onHide={() => setShowLocationModal(false)}
        centered
      >
        <Modal.Header className="border-0 pb-0">
          <Modal.Title className="fw-bold">Kayıtlı Lokasyonlar</Modal.Title>
          <Button
            variant="link"
            onClick={() => setShowLocationModal(false)}
            className="p-0"
          >
            <X size={24} />
          </Button>
        </Modal.Header>
        <Modal.Body className="pt-0">
          <div className="text-center py-4">
            <InfoCircle size={48} className="text-success mb-3" />
            <h5>Kayıtlı lokasyon bulunamadı</h5>
            <p className="text-muted">
              Birden fazla lokasyonu kaydedebilmek ve premium özelliklerin
              kilidini açmak için sürdürülebilir üye olun.
            </p>
          </div>

          <div className="d-flex justify-content-between">
            <Button
              variant="link"
              className="text-success fw-medium text-decoration-none"
            >
              Daha Fazla Bilgi
            </Button>
            <Button
              variant="success"
              className="px-4"
              onClick={() => setShowLocationModal(false)}
            >
              Tamam
            </Button>
          </div>
        </Modal.Body>
      </Modal>

      {/* Main Content */}
      <Container fluid className="flex-grow-1 p-0 overflow-hidden">
        <Row className="h-100 g-0">
          {/* Left Menu */}
          {viewMode === "detailed" && (
            <Col
              xs={3}
              className="h-100 p-3 d-flex flex-column"
              style={{ backgroundColor: "#f8fdf2" }}
            >
              <div className="d-flex flex-column h-100">
                <div>
                  <Card className="border-0 bg-white shadow-sm mb-4 w-100 text-center">
                    <Card.Body>
                      <Button
                        variant="success"
                        className="mb-3 rounded-circle p-3"
                        onClick={() => setShowOfferModal(true)}
                      >
                        <Image
                          src="https://storage.googleapis.com/a1aa/image/e282e142-ed07-4c0d-7f37-e7c330a2cb0e.jpg"
                          width={28}
                          height={28}
                          alt="Yardım Et"
                        />
                      </Button>
                      <h6 className="fw-bold">Yardım Et</h6>
                    </Card.Body>
                  </Card>

                  <HelpOfferModal
                    show={showOfferModal}
                    onHide={() => setShowOfferModal(false)}
                  />

                  <Card className="border-0 bg-white shadow-sm mb-4 w-100 text-center">
                    <Card.Body>
                      <Button
                        variant="outline-success"
                        className="mb-3 rounded-circle p-3"
                        onClick={() => setShowRequestModal(true)}
                      >
                        <Image
                          src="https://storage.googleapis.com/a1aa/image/4cd4c90a-8c8c-4427-8d88-81de8a7dc1ed.jpg"
                          width={28}
                          height={28}
                        />
                      </Button>
                      <h6 className="fw-bold">Talep Et</h6>
                    </Card.Body>
                  </Card>

                  <HelpRequestModal
                    show={showRequestModal}
                    onHide={() => setShowRequestModal(false)}
                  />
                </div>

                <div className="mt-auto text-center">
                  <div className="small">
                    <Button
                      variant="link"
                      className="text-success text-decoration-none p-0 mb-1 d-block mx-auto"
                    >
                      Topluluk Kuralları
                    </Button>
                    <Button
                      variant="link"
                      className="text-success text-decoration-none p-0 d-block mx-auto"
                    >
                      Yardım Merkezi
                    </Button>
                  </div>
                </div>
              </div>
            </Col>
          )}

          {/* Main Feed */}
          <Col
            xs={viewMode === "detailed" ? 6 : 12}
            className="h-100 p-0 bg-white"
            style={{ overflowY: "auto" }}
          >
            {/* Sticky Header with Tabs */}
            <div className="sticky-top bg-white pt-3 pb-2 border-bottom z-index-10">
              <div className="d-flex justify-content-between align-items-center px-3 mb-2">
                <Tabs
                  activeKey={activeTab}
                  onSelect={(k) => setActiveTab(k)}
                  className="mb-0 custom-tabs"
                >
                  <Tab
                    eventKey="aktif"
                    title={<span className="text-success">Aktif</span>}
                  />
                  <Tab
                    eventKey="tum"
                    title={<span className="text-success">Tümü</span>}
                  />
                  <Tab
                    eventKey="kaydedilen"
                    title={<span className="text-success">Kaydedilenler</span>}
                  />
                </Tabs>
              </div>
            </div>

            {/* Post List */}
            {viewMode === "detailed" ? (
              <ListGroup variant="flush" className="pb-5">
                {samplePosts.map((post) => (
                  <ListGroup.Item
                    key={post.id}
                    className="border-bottom p-0 bg-transparent"
                  >
                    <Card className="border-0 rounded-lg shadow-sm mb-3 overflow-hidden">
                      {/* Post Header */}
                      <Card.Header className="bg-white border-0 d-flex align-items-center p-3">
                        <Image
                          src={post.avatar}
                          roundedCircle
                          width={48}
                          height={48}
                          className="me-3 border border-success"
                        />
                        <div className="flex-grow-1">
                          <div className="fw-bold text-dark">{post.user}</div>
                          <small className="text-muted d-flex align-items-center">
                            <GeoAlt size={12} className="me-1" />{" "}
                            {post.location} • {post.time}
                          </small>
                        </div>
                        <Dropdown>
                          <Dropdown.Toggle
                            variant="link"
                            className="p-0 text-dark"
                          >
                            <ThreeDots />
                          </Dropdown.Toggle>
                          <Dropdown.Menu>
                            <Dropdown.Item>Paylaş</Dropdown.Item>
                            <Dropdown.Item>Kaydet</Dropdown.Item>
                            <Dropdown.Item>Rapor Et</Dropdown.Item>
                          </Dropdown.Menu>
                        </Dropdown>
                      </Card.Header>

                      {/* Post Image */}
                      {post.images.length > 0 && (
                        <div className="position-relative">
                          <Card.Img
                            variant="top"
                            src={post.images[0]}
                            style={{ height: "350px", objectFit: "cover" }}
                            onClick={() => handlePostClick(post)}
                            className="cursor-pointer"
                          />
                          {post.type === "yardim" && (
                            <Badge
                              pill
                              bg="success"
                              className="position-absolute top-2 start-2"
                            >
                              Yardım Talebi
                            </Badge>
                          )}
                        </div>
                      )}

                      {/* Post Content */}
                      <Card.Body className="pb-2">
                        <Card.Title className="h5">{post.title}</Card.Title>
                        <Card.Text className="text-muted mb-3">
                          {post.content}
                        </Card.Text>

                        {/* Action Buttons */}
                        <div className="d-flex justify-content-between align-items-center mb-3">
                          <small className="text-muted d-flex align-items-center">
                            <GeoAltFill
                              className="me-1 text-success"
                              size={14}
                            />
                            {post.detailedLocation}
                          </small>
                          <Button
                            variant={
                              post.type === "yardim"
                                ? "success"
                                : "outline-success"
                            }
                            size="sm"
                            className="rounded-pill px-3"
                          >
                            {post.type === "yardim"
                              ? "İlgileniyorum"
                              : "Yardım Edebilirim"}
                          </Button>
                        </div>

                        {/* Comments Preview */}
                        {post.comments.length > 0 && (
                          <div className="mb-3">
                            {post.comments.slice(0, 2).map((comment, index) => (
                              <div key={index} className="d-flex mb-2">
                                <strong className="me-2">{comment.user}:</strong>
                                <span>{comment.content}</span>
                              </div>
                            ))}
                            {post.comments.length > 2 && (
                              <Button
                                variant="link"
                                className="p-0 text-muted small"
                                onClick={() => handlePostClick(post)}
                              >
                                {post.comments.length - 2} yorum daha göster
                              </Button>
                            )}
                          </div>
                        )}

                        {/* Comment Input */}
                        <div className="d-flex align-items-center mb-2">
                          <Form.Control
                            type="text"
                            placeholder="Yorum yaz..."
                            size="sm"
                            className="rounded-pill flex-grow-1 me-2"
                          />
                          <Button 
                            variant="success" 
                            size="sm" 
                            className="rounded-circle p-1"
                            style={{ marginLeft: "8px" }} // Gönderme tuşu boşluğu arttırıldı
                          >
                            <Send size={16} />
                          </Button>
                        </div>

                        {/* Interaction Icons */}
                        <div className="border-top pt-3 d-flex justify-content-around">
                          <Button variant="link" className="text-dark p-0">
                            <Chat size={20} className="text-success me-1" />
                            <span>{post.comments.length}</span>
                          </Button>
                          <Button variant="link" className="text-dark p-0">
                            <Heart size={20} className="text-success me-1" />
                            <span>{post.likes}</span>
                          </Button>
                          <Button
                            variant="link"
                            className="text-dark p-0"
                            onClick={() => toggleSavePost(post.id)}
                          >
                            <Bookmark size={20} className="text-success me-1" />
                          </Button>
                          <Button variant="link" className="text-dark p-0">
                            <Gift size={20} className="text-success me-1" />
                          </Button>
                        </div>
                      </Card.Body>
                    </Card>
                  </ListGroup.Item>
                ))}
              </ListGroup>
            ) : (
              /* Grid View */
              <div className="p-3 pb-5" style={{ backgroundColor: "#f8fdf2" }}>
                <Row xs={2} md={3} lg={4} className="g-3">
                  {samplePosts.map((post) => (
                    <Col key={post.id} className="mb-3">
                      <Card className="h-100 border-0 shadow-sm overflow-hidden">
                        <div
                          className="position-relative"
                          onClick={() => handlePostClick(post)}
                          style={{ cursor: "pointer" }}
                        >
                          <Card.Img
                            variant="top"
                            src={post.images[0]}
                            style={{ height: "180px", objectFit: "cover" }}
                          />
                          {post.type === "yardim" && (
                            <Badge
                              pill
                              bg="success"
                              className="position-absolute top-2 start-2"
                            >
                              Yardım
                            </Badge>
                          )}
                        </div>
                        <Card.Body className="p-3">
                          <Card.Title className="small fw-bold mb-1">
                            {post.title}
                          </Card.Title>
                          <small className="text-muted d-flex align-items-center mb-2">
                            <GeoAlt size={12} className="me-1" />{" "}
                            {post.location}
                          </small>
                          <div className="d-flex justify-content-around">
                            <div className="d-flex align-items-center">
                              <Chat size={16} className="text-success me-1" />
                              <small>{post.comments.length}</small>
                            </div>
                            <div className="d-flex align-items-center">
                              <Heart size={16} className="text-success me-1" />
                              <small>{post.likes}</small>
                            </div>
                            <Bookmark size={16} className="text-success" />
                            <Gift size={16} className="text-success" />
                          </div>
                        </Card.Body>
                      </Card>
                    </Col>
                  ))}
                </Row>
              </div>
            )}
          </Col>

          {/* Right Menu */}
          {viewMode === "detailed" && (
            <Col
              xs={3}
              className="h-100 p-4 d-none d-lg-flex flex-column"
              style={{ backgroundColor: "#f8fdf2" }}
            >
              <div className="d-flex flex-column h-100">
                <div>
                  <Card className="border-0 bg-white shadow-sm mb-4">
                    <Card.Body className="text-center">
                      <div className="bg-success bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center p-3 mb-3">
                        <Leaf size={24} className="text-success" />
                      </div>
                      <h5 className="fw-bold mb-3">El Uzat Topluluğu</h5>
                      <p className="small text-muted mb-3">
                        Komşularınızla yardımlaşarak daha güçlü bir topluluk
                        oluşturun.
                      </p>
                      <Button variant="success" className="w-100">
                        Topluluğa Katıl
                      </Button>
                    </Card.Body>
                  </Card>

                  <Card className="border-0 bg-white shadow-sm">
                    <Card.Body>
                      <h6 className="fw-bold mb-3">Yakındaki Etkinlikler</h6>
                      <div className="d-flex mb-3">
                        <div className="flex-shrink-0 me-3">
                          <div
                            className="bg-light rounded p-2 text-center"
                            style={{ width: "50px" }}
                          >
                            <div className="fw-bold text-success">15</div>
                            <div className="small">Haz</div>
                          </div>
                        </div>
                        <div>
                          <div className="fw-bold">Yardım Günü</div>
                          <small className="text-muted">Kadıköy Halk Parkı</small>
                        </div>
                      </div>
                      <Button variant="outline-success" className="w-100">
                        Tüm Etkinlikler
                      </Button>
                    </Card.Body>
                  </Card>
                </div>
              </div>
            </Col>
          )}
        </Row>
      </Container>

      {/* Bottom Navigation */}
      <BottomNav />

      {/* Post Menu Modal */}
      <Modal
        show={showPostMenu}
        onHide={() => setShowPostMenu(false)}
        centered
        className="modal-bottom"
      >
        <Modal.Body className="p-0">
          <ListGroup variant="flush">
            <ListGroup.Item action className="text-danger">
              Gönderiyi Bildir
            </ListGroup.Item>
            <ListGroup.Item action>Beğenenleri Gör</ListGroup.Item>
            <ListGroup.Item action>Paylaş</ListGroup.Item>
            <ListGroup.Item action onClick={() => setShowPostMenu(false)}>
              İptal
            </ListGroup.Item>
          </ListGroup>
        </Modal.Body>
      </Modal>

      {/* Detail Modal */}
      <DetailModal
        post={selectedPost}
        show={selectedPost !== null}
        onHide={() => setSelectedPost(null)}
        onSave={toggleSavePost}
      />
    </div>
  );
};

export default Home;