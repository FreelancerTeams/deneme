import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Container, Button, Card, Row, Col } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';

const MembershipPage = () => {
  const navigate = useNavigate();
  
  const primaryColor = '#38900f'; // Verdiğiniz yeşil renk
  const whiteColor = '#ffffff';
  const darkText = '#31383f';
  const lightText = '#636c76';

  return (
    <div className="d-flex flex-column min-vh-100" style={{ backgroundColor: whiteColor }}>
      {/* Header */}
      <header className="sticky-top bg-white py-3 border-bottom">
        <Container>
          <div className="d-flex align-items-center">
            <Button 
              variant="link" 
              className="p-0 me-3" 
              onClick={() => navigate(-1)}
            >
              <i className="bi bi-arrow-left fs-4" style={{ color: darkText }}></i>
            </Button>
            <h1 className="m-0 fs-5 fw-bold" style={{ color: darkText }}>Sürdürülebilir Üye Olun</h1>
          </div>
        </Container>
      </header>

      {/* Main Content */}
      <main className="flex-grow-1 py-4">
        <Container>
          {/* Logo/Image */}
          <div className="text-center mb-4">
            <img 
              src="https://buynothingapp.com/2df0e9db79be5ba7cf4f.png" 
              alt="BuyNothing" 
              className="img-fluid mb-3" 
              style={{ maxHeight: '80px' }}
            />
          </div>

          {/* Features */}
          <Card className="border-0 mb-4">
            <Card.Body className="px-0">
              <div className="d-flex mb-3">
                <div className="me-3">
                  <i className="bi bi-globe fs-4" style={{ color: primaryColor }}></i>
                </div>
                <div>
                  <h6 className="fw-bold mb-1" style={{ color: darkText }}>Küresel Paylaşım</h6>
                  <p className="mb-0 small" style={{ color: lightText }}>
                    Gönderilerinizi daha geniş bir kitleyle paylaşın. <span style={{ color: primaryColor, textDecoration: 'underline' }}>Daha fazla bilgi</span>
                  </p>
                </div>
              </div>

              <div className="d-flex mb-3">
                <div className="me-3">
                  <i className="bi bi-arrow-up-circle fs-4" style={{ color: primaryColor }}></i>
                </div>
                <div>
                  <h6 className="fw-bold mb-1" style={{ color: darkText }}>Gönderileri Öne Çıkarma</h6>
                  <p className="mb-0 small" style={{ color: lightText }}>
                    Önemli gönderilerinizin görünürlüğünü artırın
                  </p>
                </div>
              </div>

              <div className="d-flex">
                <div className="me-3">
                  <i className="bi bi-bookmark fs-4" style={{ color: primaryColor }}></i>
                </div>
                <div>
                  <h6 className="fw-bold mb-1" style={{ color: darkText }}>Yer İşaretleri</h6>
                  <p className="mb-0 small" style={{ color: lightText }}>
                    Önemli içerikleri kolayca kaydedin
                  </p>
                </div>
              </div>
            </Card.Body>
          </Card>

          {/* Pricing Options */}
          <Row className="g-3 mb-4">
            <Col md={6}>
              <Card className="h-100 border rounded-3 text-center p-3">
                <h6 className="fw-bold mb-2">YILLIK ABONELİK</h6>
                <h3 className="fw-bold mb-0" style={{ color: primaryColor }}>$49.99</h3>
                <small className="d-block mb-2" style={{ color: lightText }}>/yıl</small>
                <span className="badge bg-success bg-opacity-10 text-success">
                  En iyi değer! %40 tasarruf
                </span>
              </Card>
            </Col>
            <Col md={6}>
              <Card className="h-100 border rounded-3 text-center p-3">
                <h6 className="fw-bold mb-2">AYLIK ABONELİK</h6>
                <h3 className="fw-bold mb-0" style={{ color: primaryColor }}>$6.99</h3>
                <small className="d-block" style={{ color: lightText }}>/ay</small>
              </Card>
            </Col>
          </Row>

          {/* Subscribe Button */}
          <Button 
            variant="success" 
            className="w-100 py-3 fw-bold mb-3 border-0"
            style={{ backgroundColor: primaryColor }}
          >
            Abone Ol
          </Button>

          {/* Footer Text */}
          <p className="text-center small mb-4" style={{ color: lightText }}>
            Bugün ücretlendirileceksiniz. İstediğiniz zaman iptal edebilirsiniz. <br />
            <span style={{ color: primaryColor, textDecoration: 'underline' }}>Abonelik koşullarını</span> ve{' '}
            <span style={{ color: primaryColor, textDecoration: 'underline' }}>iptal politikasını</span> inceleyin
          </p>

          {/* Skip Button */}
          <div className="text-center">
            <Button 
              variant="link" 
              className="fw-bold"
              style={{ color: primaryColor }}
              onClick={() => navigate(-1)}
            >
              Şimdilik Atla
            </Button>
          </div>
        </Container>
      </main>
    </div>
  );
};

export default MembershipPage;