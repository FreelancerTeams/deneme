import React, { useState, useRef } from 'react';
import { 
  Modal, 
  Form, 
  Button, 
  Stack, 
  FormCheck,
  Badge,
  FloatingLabel,
  Alert,
  Image,
  Container,
  ProgressBar,
  InputGroup
} from 'react-bootstrap';
import { 
  X, 
  Globe, 
  People, 
  Palette,
  InfoCircle,
  ChevronDown,
  PersonCircle,
  Lightbulb,
  ArrowLeft,
  Camera,
  Trash,
  Calendar,
  Clock,
  GeoAlt
} from 'react-bootstrap-icons';

const EventCreationModal = ({ show, onHide, onCreate }) => {
  const [eventName, setEventName] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [location, setLocation] = useState('');
  const [isPublic, setIsPublic] = useState(true);
  const [showInfoModal, setShowInfoModal] = useState(false);
  const [selectedColor, setSelectedColor] = useState('#28a745');
  const [error, setError] = useState('');
  const [eventImage, setEventImage] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef(null);

  // Green theme colors to match EventsPage
  const themeColors = {
    primary: '#28a745',
    light: '#d4edda',
    dark: '#218838',
    icon: '#28a745'
  };

  const colorOptions = [
    '#28a745', '#17a2b8', '#6f42c1', 
    '#fd7e14', '#dc3545', '#ffc107', 
    '#20c997', '#6610f2', '#e83e8c'
  ];

  const sampleEventImages = [
    'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
    'https://images.unsplash.com/photo-1511578314322-379afb476865?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
    'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80'
  ];

  const handleSubmit = () => {
    if (!eventName.trim()) {
      setError('Lütfen bir etkinlik adı girin');
      return;
    }
    
    if (eventName.length < 3) {
      setError('Etkinlik adı en az 3 karakter olmalıdır');
      return;
    }
    
    if (!date) {
      setError('Lütfen bir tarih seçin');
      return;
    }
    
    if (!time) {
      setError('Lütfen bir saat seçin');
      return;
    }
    
    if (!location.trim()) {
      setError('Lütfen bir konum girin');
      return;
    }
    
    const eventData = {
      eventName,
      description,
      date,
      time,
      location,
      isPublic,
      color: selectedColor,
      image: eventImage
    };
    
    onCreate(eventData);
    onHide();
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setIsUploading(true);
      setUploadProgress(0);
      
      const interval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setIsUploading(false);
            return 100;
          }
          return prev + 10;
        });
      }, 200);
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setEventImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current.click();
  };

  const removeImage = () => {
    setEventImage(null);
  };

  return (
    <>
      {/* Main Modal */}
      <Modal 
        show={show} 
        onHide={onHide} 
        fullscreen
        centered
        backdrop="static"
        className="modern-event-modal"
      >
        <Modal.Header className="border-0 px-4 pt-3 pb-0">
          <div className="d-flex justify-content-between w-100 align-items-center">
            <Button 
              variant="link" 
              onClick={onHide} 
              className="p-0 text-muted fs-5 close-btn"
            >
              İptal
            </Button>
            
            <div className="text-center">
              <span className="fw-bold fs-5" style={{color: themeColors.dark}}>Yeni Etkinlik</span>
            </div>
            
            <Button 
              variant="success" 
              className="submit-btn px-3 py-1 rounded-3 fw-medium"
              disabled={!eventName.trim() || !date || !time || !location.trim()}
              style={{backgroundColor: themeColors.primary, borderColor: themeColors.primary}}
              onClick={handleSubmit}
            >
              Oluştur
            </Button>
          </div>
        </Modal.Header>

        <Modal.Body className="px-4 pb-5">
          {error && (
            <Alert variant="danger" className="mt-3 mb-4 rounded-3">
              {error}
            </Alert>
          )}

          {/* Image Upload Section */}
          <div className="mb-4">
            <div 
              className="ratio ratio-16x9 bg-light rounded-3 overflow-hidden mb-3 position-relative"
              style={{backgroundColor: selectedColor + '20'}}
            >
              {eventImage ? (
                <>
                  <img 
                    src={eventImage} 
                    alt="Etkinlik görseli" 
                    className="object-fit-cover w-100 h-100"
                  />
                  <Button 
                    variant="danger" 
                    size="sm" 
                    className="position-absolute top-0 end-0 m-2 rounded-circle p-2"
                    onClick={removeImage}
                  >
                    <Trash size={16} />
                  </Button>
                </>
              ) : (
                <div className="d-flex flex-column align-items-center justify-content-center h-100 gap-2">
                  <People size={48} style={{color: selectedColor}} />
                  <span className="text-muted">Görsel ekleyin</span>
                </div>
              )}
            
              
              <input 
                ref={fileInputRef}
                type="file" 
                accept="image/*" 
                onChange={handleImageUpload}
                className="d-none"
              />
              
              {isUploading && (
                <div className="position-absolute bottom-0 start-0 end-0 p-2">
                  <ProgressBar 
                    now={uploadProgress} 
                    label={`${uploadProgress}%`} 
                    style={{height: '6px'}}
                  />
                </div>
              )}
            </div>
            
            <div className="d-flex justify-content-center gap-2">
              {sampleEventImages.map((img, index) => (
                <div 
                  key={index} 
                  className="ratio ratio-1x1 rounded-2 overflow-hidden"
                  style={{
                    width: '60px', 
                    cursor: 'pointer',
                    border: eventImage === img ? `2px solid ${themeColors.primary}` : '2px solid transparent'
                  }}
                  onClick={() => setEventImage(img)}
                >
                  <img 
                    src={img} 
                    alt={`Örnek görsel ${index + 1}`} 
                    className="object-fit-cover"
                  />
                </div>
              ))}
            </div>
          </div>

          <Form>
            <Form.Group className="mb-4">
              <Form.Control
                type="text"
                placeholder="Etkinlik Adı"
                value={eventName}
                onChange={(e) => {
                  setEventName(e.target.value);
                  setError('');
                }}
                className="modern-input py-3 border-0 border-bottom rounded-0 fs-5"
                style={{
                  borderBottom: `2px solid ${themeColors.primary}`,
                  paddingLeft: '0'
                }}
              />
            </Form.Group>

            <Form.Group className="mb-4">
              <Form.Control
                as="textarea"
                placeholder="Açıklama (Opsiyonel)"
                style={{ 
                  height: '120px',
                  borderBottom: `2px solid ${themeColors.primary}`,
                  paddingLeft: '0'
                }}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="modern-input border-0 border-bottom rounded-0 fs-5"
              />
            </Form.Group>

            {/* Date and Time */}
            <div className="row g-3 mb-4">
              <div className="col-md-6">
                <div className="position-relative">
                  <Calendar className="input-icon" style={{color: themeColors.primary}} />
                  <Form.Control
                    type="date"
                    placeholder="Tarih"
                    value={date}
                    onChange={(e) => {
                      setDate(e.target.value);
                      setError('');
                    }}
                    className="modern-input py-3 border-0 border-bottom rounded-0 fs-5 ps-4"
                    style={{borderBottom: `2px solid ${themeColors.primary}`}}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="position-relative">
                  <Clock className="input-icon" style={{color: themeColors.primary}} />
                  <Form.Control
                    type="time"
                    placeholder="Saat"
                    value={time}
                    onChange={(e) => {
                      setTime(e.target.value);
                      setError('');
                    }}
                    className="modern-input py-3 border-0 border-bottom rounded-0 fs-5 ps-4"
                    style={{borderBottom: `2px solid ${themeColors.primary}`}}
                  />
                </div>
              </div>
            </div>

            {/* Location */}
            <div className="mb-4">
              <div className="position-relative">
                <GeoAlt className="input-icon" style={{color: themeColors.primary}} />
                <Form.Control
                  type="text"
                  placeholder="Konum"
                  value={location}
                  onChange={(e) => {
                    setLocation(e.target.value);
                    setError('');
                  }}
                  className="modern-input py-3 border-0 border-bottom rounded-0 fs-5 ps-4"
                  style={{borderBottom: `2px solid ${themeColors.primary}`}}
                />
              </div>
            </div>
            {/* Visibility Setting */}
            <div className="mb-4 p-3 rounded-3" style={{backgroundColor: themeColors.light + '40'}}>
              <FormCheck
                type="switch"
                id="is-public"
                label={
                  <span className="d-flex align-items-center option-item">
                    <Globe className="me-2" size={20} style={{color: themeColors.primary}} />
                    <span className="fw-medium">Herkese açık olarak paylaş</span>
                  </span>
                }
                checked={isPublic}
                onChange={(e) => setIsPublic(e.target.checked)}
              />
              <small className="text-muted d-block mt-1 ps-4">
                Herkese açık etkinlikler tüm kullanıcılar tarafından görülebilir
              </small>
            </div>
          </Form>

          {/* Fixed Camera Button at bottom */}
          <div className="camera-btn-container">
            <Button 
              variant="success" 
              className="camera-btn rounded-circle align-items-center"
              style={{backgroundColor: themeColors.primary, borderColor: themeColors.primary}}
              onClick={triggerFileInput}
            >
              <Camera size={22} />
            </Button>
          </div>
        </Modal.Body>
      </Modal>

      <style jsx>{`
        .modern-event-modal {
          font-family: 'Segoe UI', system-ui, sans-serif;
        }
        
        .modern-event-modal .modal-content {
          border-radius: 0;
          border: none;
          min-height: 100vh;
          background-color: #ffffff;
        }
        
        .close-btn {
          color: #6c757d !important;
          font-weight: 500;
        }
        
        .submit-btn {
          color: white !important;
        }
        
        .submit-btn:disabled {
          opacity: 0.65;
        }
        
        .modern-input {
          font-size: 18px;
          line-height: 1.6;
          resize: none;
          background-color: transparent;
        }
        
        .modern-input:focus {
          box-shadow: none;
          outline: none;
        }
        
        .section-label {
          font-size: 0.75rem;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          font-weight: 600;
          display: flex;
          align-items: center;
        }
        
        .option-item {
          color: #495057;
          padding: 8px 0;
          transition: color 0.2s;
        }
        
        .option-item:hover {
          color: ${themeColors.dark};
        }
        
        .color-option {
          border-radius: 50%;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: transform 0.2s;
          border: 2px solid transparent;
        }
        
        .color-option:hover {
          transform: scale(1.1);
        }
        
        .color-option.selected {
          border-color: #212529;
          transform: scale(1.1);
        }
        
        .check-mark {
          color: white;
          font-weight: bold;
          text-shadow: 0 0 2px rgba(0,0,0,0.5);
        }
        
        .input-icon {
          position: absolute;
          top: 16px;
          left: 0;
          z-index: 1;
        }
        
        .camera-btn-container {
          position: fixed;
          bottom: 20px;
          left: 0;
          right: 0;
          display: flex;
          justify-content: center;
          padding: 16px;
          background: linear-gradient(transparent, white 70%);
        }
        
        .camera-btn {
          width: 56px;
          height: 56px;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
          transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .camera-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(0, 0, 0, 0.2);
        }
      `}</style>
    </>
  );
};

export default EventCreationModal;