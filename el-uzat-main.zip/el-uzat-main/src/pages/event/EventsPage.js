import React, { useState } from "react";
import {
  Container,
  Button,
  Card,
  ListGroup,
  Form,
  Tab,
  Tabs,
  Badge,
  Image,
  Stack,
  InputGroup,
  Navbar,
  Collapse
} from "react-bootstrap";
import {
  ChevronLeft,
  Search as SearchIcon,
  People,
  CalendarEvent,
  GeoAlt,
  Plus,
  ArrowRight,
  Heart,
  X,
  Share
} from "react-bootstrap-icons";
import EventCreationModal from "./EventCreationModal";

// Sample events data
const upcomingEvents = [
  {
    id: 1,
    title: "Yardım Günü",
    date: "15 Haziran 2023",
    time: "14:00 - 17:00",
    location: "Kadıköy Halk Parkı",
    description: "Fazla eşyalarınızı getirip ihtiyacı olanlarla paylaşabileceğiniz bir etkinlik",
    participants: 24,
    category: "",
    image: "https://images.unsplash.com/photo-1601758003122-53c40e686a19?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80",
  },
  {
    id: 2,
    title: "Eşya Takas Şenliği",
    date: "22 Haziran 2023",
    time: "11:00 - 16:00",
    location: "Beşiktaş Meydan",
    description: "Kullanmadığınız eşyaları takas edebileceğiniz eğlenceli bir etkinlik",
    participants: 18,
    category: "",
    image: "https://images.unsplash.com/photo-1605000797499-95a51c5269ae?ixlib=rb-4.0.3&auto=format&fit=crop&w=1471&q=80",
  },
  {
    id: 3,
    title: "Komşu Kahvesi",
    date: "29 Haziran 2023",
    time: "10:00 - 12:00",
    location: "Moda Sahil Kafe",
    description: "Mahalle sakinleriyle tanışıp kaynaşabileceğiniz samimi bir buluşma",
    participants: 12,
    category: "",
    image: "https://images.unsplash.com/photo-1514933651103-005eec06c04b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1374&q=80",
  },
];

const pastEvents = [
  {
    id: 4,
    title: "Kitap Bağış Kampanyası",
    date: "5 Mayıs 2023",
    participants: 32,
    category: "",
    image: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1374&q=80",
  },
  {
    id: 5,
    title: "Park Temizliği",
    date: "22 Nisan 2023",
    participants: 15,
    category: "",
    image: "https://images.unsplash.com/photo-1605007493699-af65834f8a00?ixlib=rb-4.0.3&auto=format&fit=crop&w=1374&q=80",
  },
];

const EventsPage = () => {
  const [activeTab, setActiveTab] = useState("upcoming");
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showCreateModal, setShowCreateModal] = useState(false);

  const handleEventClick = (event) => {
    setSelectedEvent(event);
  };

  const handleBackToList = () => {
    setSelectedEvent(null);
  };

  const toggleSearch = () => {
    setShowSearch(!showSearch);
    if (showSearch) {
      setSearchQuery("");
    }
  };

  const handleCreateEvent = (eventData) => {
    console.log("Yeni etkinlik:", eventData);
    setShowCreateModal(false);
    // Here you would typically add the new event to your state or send to API
  };

  const filteredEvents = (events) => {
    if (!searchQuery) return events;
    return events.filter(event => 
      event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (event.description && event.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (event.location && event.location.toLowerCase().includes(searchQuery.toLowerCase())) ||
      event.category.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  const renderEventList = () => (
    <>
      <div className="d-flex justify-content-between mb-4 gap-3">
        <Button
          variant="success"
          className="flex-grow-1 rounded-pill py-2 d-flex align-items-center justify-content-center"
          onClick={() => setShowCreateModal(true)}
        >
          <Plus size={18} className="me-2" /> Etkinlik Oluştur
        </Button>
        <Button
          variant="outline-success"
          className="flex-grow-1 rounded-pill py-2 d-flex align-items-center justify-content-center"
          onClick={toggleSearch}
        >
          <SearchIcon size={18} className="me-2" /> Etkinlik Ara
        </Button>
      </div>

      <Tabs
        activeKey={activeTab}
        onSelect={(k) => setActiveTab(k)}
        className="mb-3"
        fill
      >
        <Tab eventKey="upcoming" title="Yaklaşan" />
        <Tab eventKey="past" title="Geçmiş" />
        <Tab eventKey="saved" title="Kaydedilenler" />
      </Tabs>

      {activeTab === "upcoming" && (
        <div className="row g-3">
          {filteredEvents(upcomingEvents).map((event) => (
            <div key={event.id} className="col-md-6">
              <EventCard event={event} onClick={() => handleEventClick(event)} />
            </div>
          ))}
        </div>
      )}

      {activeTab === "past" && (
        <Card className="border-0 shadow-sm">
          <Card.Body className="p-0">
            <ListGroup variant="flush">
              {filteredEvents(pastEvents).map((event) => (
                <PastEventItem 
                  key={event.id} 
                  event={event} 
                  onClick={() => handleEventClick(event)} 
                />
              ))}
            </ListGroup>
            <Button
              variant="light"
              className="w-100 rounded-0 py-3 text-success border-top"
            >
              Daha Fazla Göster <ArrowRight className="ms-2" />
            </Button>
          </Card.Body>
        </Card>
      )}

      {activeTab === "saved" && (
        <div className="text-center py-5">
          <div className="bg-light rounded-circle d-inline-flex p-4 mb-4">
            <Heart size={40} className="text-muted" />
          </div>
          <h5>Kaydedilmiş Etkinlik Yok</h5>
          <p className="text-muted mb-3">
            Beğendiğiniz etkinlikleri kaydedin, burada görünsün
          </p>
          <Button variant="success" className="rounded-pill px-4">
            Etkinliklere Göz At
          </Button>
        </div>
      )}
    </>
  );

  const renderEventDetail = () => (
    <div className="animate__animated animate__fadeIn">
      <EventDetailCard event={selectedEvent} onBack={handleBackToList} />
    </div>
  );

  return (
    <div className="bg-light" style={{ minHeight: "100vh" }}>
      <Navbar bg="white" className="border-bottom sticky-top shadow-sm">
        <Container>
          <Button
            variant="link"
            className="p-0 me-2"
            onClick={selectedEvent ? handleBackToList : null}
          >
            <ChevronLeft size={20} />
          </Button>
          <Navbar.Brand className="fw-bold">
            {selectedEvent ? selectedEvent.title : "Etkinlikler"}
          </Navbar.Brand>
          <div className="ms-auto">
            <Button variant="link" className="p-0 text-dark" onClick={toggleSearch}>
              {showSearch ? <X size={20} /> : <SearchIcon size={20} />}
            </Button>
          </div>
        </Container>
      </Navbar>

      <Collapse in={showSearch}>
        <div className="bg-white shadow-sm">
          <Container className="py-3">
            <InputGroup>
              <InputGroup.Text className="bg-white border-end-0">
                <SearchIcon />
              </InputGroup.Text>
              <Form.Control
                type="search"
                placeholder="Etkinlik ara..."
                className="border-start-0"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </InputGroup>
          </Container>
        </div>
      </Collapse>

      <Container className="py-3">
        {!selectedEvent ? renderEventList() : renderEventDetail()}
      </Container>

      <EventCreationModal 
        show={showCreateModal} 
        onHide={() => setShowCreateModal(false)}
        onCreate={handleCreateEvent}
      />

      <style>{`
        .nav-tabs .nav-link {
          border: none;
          color: #495057;
          font-weight: 500;
          padding: 0.75rem 1rem;
          transition: all 0.2s;
        }
        .nav-tabs .nav-link.active {
          color: #28a745;
          border-bottom: 2px solid #28a745;
          background-color: transparent;
        }
        .nav-tabs .nav-link:hover:not(.active) {
          color: #28a745;
          border-bottom: 2px solid rgba(40, 167, 69, 0.3);
        }
        .animate__animated {
          animation-duration: 0.3s;
        }
        .object-fit-cover {
          object-fit: cover;
        }
        .cursor-pointer {
          cursor: pointer;
        }
        .form-floating label {
          color: #6c757d;
        }
        .form-control:focus, .form-select:focus {
          border-color: #28a745;
          box-shadow: 0 0 0 0.25rem rgba(40, 167, 69, 0.25);
        }
      `}</style>
    </div>
  );
};

// Extracted components
const EventCard = ({ event, onClick }) => (
  <Card className="border-0 shadow-sm h-100 cursor-pointer" onClick={onClick}>
    <div className="position-relative">
      <Card.Img
        variant="top"
        src={event.image}
        height="160"
        className="object-fit-cover"
      />
      <Badge
        bg="light"
        className="position-absolute top-2 end-2 text-dark fw-normal"
      >
        {event.category}
      </Badge>
    </div>
    <Card.Body>
      <Card.Title>{event.title}</Card.Title>
      <Card.Text className="text-muted small">
        {event.description}
      </Card.Text>
      <div className="d-flex align-items-center text-muted small mb-2">
        <CalendarEvent className="me-2" size={14} />
        {event.date} • {event.time}
      </div>
      <div className="d-flex align-items-center text-muted small mb-3">
        <GeoAlt className="me-2" size={14} />
        {event.location}
      </div>
      <div className="d-flex justify-content-between align-items-center">
        <div className="d-flex align-items-center">
          <People className="me-1" size={14} />
          <span className="small">
            {event.participants} katılımcı
          </span>
        </div>
        <Button
          variant="success"
          size="sm"
          className="rounded-pill"
        >
          Katıl
        </Button>
      </div>
    </Card.Body>
  </Card>
);

const PastEventItem = ({ event, onClick }) => (
  <ListGroup.Item
    action
    onClick={onClick}
    className="px-3 py-3"
  >
    <div className="d-flex gap-3">
      <img
        src={event.image}
        alt={event.title}
        width={80}
        height={80}
        className="rounded-3 object-fit-cover"
      />
      <div className="flex-grow-1">
        <div className="d-flex justify-content-between align-items-start">
          <div>
            <h6 className="mb-1">{event.title}</h6>
            <div className="d-flex gap-3 align-items-center">
              <span className="text-muted small">
                <CalendarEvent className="me-1" size={12} /> {event.date}
              </span>
              <span className="text-muted small">
                <People className="me-1" size={12} /> {event.participants} katılımcı
              </span>
            </div>
          </div>
        </div>
        <div className="d-flex justify-content-between align-items-center mt-2">
          <Badge bg="light" text="dark" className="fw-normal">
            {event.category}
          </Badge>
          <Button
            variant="outline-primary"
            size="sm"
            className="rounded-pill"
          >
            Detaylar
          </Button>
        </div>
      </div>
    </div>
  </ListGroup.Item>
);

const EventDetailCard = ({ event, onBack }) => (
  <>
    <Card className="border-0 shadow-sm mb-4 overflow-hidden">
      <Card.Img
        variant="top"
        src={event.image}
        height="200"
        className="object-fit-cover"
      />
      <Card.Body>
        <Badge bg="light" text="dark" className="mb-3">
          {event.category}
        </Badge>
        <Card.Title>{event.title}</Card.Title>
        <Card.Text>{event.description}</Card.Text>

        <div className="d-flex align-items-center text-muted mb-3">
          <CalendarEvent className="me-2" size={16} />
          <span>
            {event.date} • {event.time}
          </span>
        </div>

        <div className="d-flex align-items-center text-muted mb-4">
          <GeoAlt className="me-2" size={16} />
          <span>{event.location}</span>
        </div>

        <div className="d-flex justify-content-between align-items-center mb-4">
          <div className="d-flex align-items-center">
            <People className="me-1" size={16} />
            <span>{event.participants} katılımcı</span>
          </div>
          <div className="d-flex gap-2">
            <Button variant="link" size="sm" className="p-1 text-dark">
              <Heart size={20} />
            </Button>
            <Button variant="link" size="sm" className="p-1 text-dark">
              <Share size={20} />
            </Button>
          </div>
        </div>

        <Button variant="success" className="w-100 rounded-pill py-2">
          Etkinliğe Katıl
        </Button>
      </Card.Body>
    </Card>

    <ParticipantsCard event={event} />
    <LocationCard event={event} />
  </>
);

const ParticipantsCard = ({ event }) => (
  <Card className="border-0 shadow-sm mb-4">
    <Card.Body>
      <h5 className="mb-3">Katılımcılar</h5>
      <div className="d-flex align-items-center mb-3">
        <Stack direction="horizontal" gap={2}>
          {[1, 2, 3, 4].map((i) => (
            <Image
              key={i}
              src={`https://randomuser.me/api/portraits/${
                i % 2 === 0 ? "women" : "men"
              }/${i + 20}.jpg`}
              roundedCircle
              width={40}
              height={40}
              className="border border-2 border-white"
              style={{ marginLeft: i > 0 ? "-10px" : "0" }}
            />
          ))}
          <div className="ms-2">
            <small className="text-muted">
              +{event.participants - 4} kişi daha
            </small>
          </div>
        </Stack>
      </div>
      <Button variant="outline-success" className="w-100 rounded-pill">
        Tüm Katılımcıları Gör
      </Button>
    </Card.Body>
  </Card>
);

const LocationCard = ({ event }) => (
  <Card className="border-0 shadow-sm">
    <Card.Body>
      <h5 className="mb-3">Konum</h5>
      <div className="bg-light rounded-3 p-4 text-center mb-3">
        <GeoAlt size={40} className="text-muted mb-2" />
        <p className="mb-0">{event.location}</p>
      </div>
      <Button variant="outline-primary" className="w-100 rounded-pill">
        Haritada Göster
      </Button>
    </Card.Body>
  </Card>
);

export default EventsPage;