import React, { useState } from 'react';
import {
  Modal,
  Button,
  Image,
  Badge,
  Form,
  ListGroup,
  Container,
  Row,
  Col,
  Dropdown,
} from 'react-bootstrap';
import {
  Heart,
  HeartFill,
  Bookmark,
  BookmarkFill,
  Gift,
  Chat,
  Send,
  ThreeDots,
  GeoAlt,
  X,
  Share,
  Flag,
  EmojiSmile,
} from 'react-bootstrap-icons';

const DetailModal = ({ post, show, onHide, onSave }) => {
  const [comment, setComment] = useState('');
  const [comments, setComments] = useState(post?.comments || []);
  const [isSaved, setIsSaved] = useState(post?.saved || false);
  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(post?.likes || 0);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  const handleCommentSubmit = (e) => {
    e.preventDefault();
    if (comment.trim()) {
      const newComment = {
        user: 'Sen',
        content: comment,
        time: 'Şimdi',
      };
      setComments([...comments, newComment]);
      setComment('');
    }
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
    setLikeCount(isLiked ? likeCount - 1 : likeCount + 1);
  };

  const handleSave = () => {
    setIsSaved(!isSaved);
    if (onSave) onSave(post.id);
  };

  if (!post) return null;

  return (
    <Modal
      show={show}
      onHide={onHide}
      centered
      fullscreen
      className="modern-modal"
      style={{ backdropFilter: 'blur(5px)' }}
    >
      <Modal.Header className="border-0 position-relative p-3">
        <div className="d-flex align-items-center w-100">
          <Image
            src={post.avatar}
            roundedCircle
            width={40}
            height={40}
            className="me-3 border border-2 border-success"
          />
          <div className="flex-grow-1">
            <h6 className="fw-bold mb-0">{post.user}</h6>
            <small className="text-muted">
              <GeoAlt size={12} className="me-1" />
              {post.location}
            </small>
          </div>
          <Dropdown align="end" className="no-arrow">
            <Dropdown.Toggle variant="link" className="text-dark p-0">
              <ThreeDots />
            </Dropdown.Toggle>
            <Dropdown.Menu className="shadow-sm border-0">
              <Dropdown.Item>
                <Share className="me-2" /> Paylaş
              </Dropdown.Item>
              <Dropdown.Item onClick={handleSave}>
                {isSaved ? (
                  <>
                    <BookmarkFill className="me-2 text-warning" /> Kaydı Kaldır
                  </>
                ) : (
                  <>
                    <Bookmark className="me-2" /> Kaydet
                  </>
                )}
              </Dropdown.Item>
              <Dropdown.Item className="text-danger">
                <Flag className="me-2" /> Bildir
              </Dropdown.Item>
              <Dropdown.Item>
                <X className="me-2" /> İlanı Kapat
              </Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <Button
          variant="link"
          onClick={onHide}
          className="position-absolute end-0 top-0 p-2 text-dark"
        >
          <X size={24} />
        </Button>
      </Modal.Header>

      <Modal.Body className="pt-0 px-0 d-flex flex-column" style={{ overflowY: 'auto' }}>
        {/* Post Content */}
        <div className="px-3 mb-3">
          <h5 className="fw-bold mb-2">{post.title}</h5>
          <p className="text-muted mb-0">{post.content}</p>
        </div>

        {/* Post Image */}
        {post.images.length > 0 && (
          <div className="position-relative mb-3">
            <Image
              src={post.images[0]}
              fluid
              className="w-100"
              style={{ maxHeight: '60vh', objectFit: 'cover' }}
            />
            {post.type === 'yardim' && (
              <Badge
                pill
                bg="success"
                className="position-absolute top-2 start-2 shadow-sm"
              >
                Yardım Talebi
              </Badge>
            )}
          </div>
        )}

        {/* Location and Action */}
        <div className="d-flex justify-content-between align-items-center px-3 mb-3">
          <div className="d-flex align-items-center">
            <GeoAlt size={16} className="text-success me-2" />
            <small className="text-muted">{post.detailedLocation}</small>
          </div>
          <Button
            variant={post.type === 'yardim' ? 'success' : 'outline-success'}
            size="sm"
            className="rounded-pill px-3 shadow-sm"
          >
            {post.type === 'yardim' ? 'İlgileniyorum' : 'Yardım Edebilirim'}
          </Button>
        </div>

        {/* Interaction Stats */}
        <div className="d-flex justify-content-between border-top border-bottom py-2 px-3 mb-3">
          <Button variant="link" className="text-muted p-0 small">
            <Chat className="me-1" /> {comments.length} yorum
          </Button>
          <Button variant="link" className="text-muted p-0 small">
            {isLiked ? <HeartFill className="me-1 text-danger" /> : <Heart className="me-1" />}
            {likeCount} beğeni
          </Button>
          <Button variant="link" className="text-muted p-0 small">
            <Gift className="me-1" /> Paylaş
          </Button>
        </div>

        {/* Comments Section */}
        <div className="px-3 mb-3 flex-grow-1">
          <h6 className="fw-bold mb-2">Yorumlar</h6>
          {comments.length > 0 ? (
            <ListGroup variant="flush" className="mb-2">
              {comments.map((comment, index) => (
                <ListGroup.Item
                  key={index}
                  className="border-0 px-0 py-1 bg-transparent"
                >
                  <div className="d-flex flex-column">
                    <div className="d-flex align-items-center mb-1">
                      <strong className="me-2">{comment.user}</strong>
                      <small className="text-muted">{comment.time}</small>
                    </div>
                    <span>{comment.content}</span>
                  </div>
                </ListGroup.Item>
              ))}
            </ListGroup>
          ) : (
            <div className="text-center py-4">
              <p className="text-muted">Henüz yorum yok</p>
              <small className="text-muted">İlk yorumu sen yap</small>
            </div>
          )}
        </div>
      </Modal.Body>

      {/* Comment Form */}
      <div className="border-top p-3 bg-white sticky-bottom">
        <Form onSubmit={handleCommentSubmit}>
          <div className="d-flex align-items-center">
            <Button 
              variant="link" 
              className="p-0 me-2" 
              onClick={() => setShowEmojiPicker(!showEmojiPicker)}
            >
              <EmojiSmile size={20} className="text-muted" />
            </Button>
            <Form.Control
              type="text"
              placeholder="Yorum yaz..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="rounded-pill flex-grow-1 me-2 border-0 bg-light"
            />
            <Button
              variant={comment.trim() ? 'success' : 'outline-secondary'}
              type="submit"
              className="rounded-circle p-2"
              disabled={!comment.trim()}
              style={{ width: '40px', height: '40px' }}
            >
              <Send size={18} />
            </Button>
          </div>
        </Form>
      </div>

      {/* Footer Actions */}
      <div className="border-top p-3 bg-white">
        <Container fluid>
          <Row className="g-2">
            <Col>
              <Button
                variant={isLiked ? 'danger' : 'outline-secondary'}
                onClick={handleLike}
                className="w-100 rounded-pill d-flex align-items-center justify-content-center"
              >
                {isLiked ? <HeartFill className="me-1" /> : <Heart className="me-1" />}
                Beğen
              </Button>
            </Col>
            <Col>
              <Button
                variant={isSaved ? 'warning' : 'outline-secondary'}
                onClick={handleSave}
                className="w-100 rounded-pill d-flex align-items-center justify-content-center"
              >
                {isSaved ? <BookmarkFill className="me-1" /> : <Bookmark className="me-1" />}
                Kaydet
              </Button>
            </Col>
            <Col>
              <Button
                variant="outline-success"
                className="w-100 rounded-pill d-flex align-items-center justify-content-center"
              >
                <Gift className="me-1" />
                Paylaş
              </Button>
            </Col>
          </Row>
        </Container>
      </div>
    </Modal>
  );
};

export default DetailModal;