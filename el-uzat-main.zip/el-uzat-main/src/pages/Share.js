import React, { useState } from 'react';
import { Button, Modal, Form } from 'react-bootstrap';

const Share = () => {
  const [verModalGoster, setVerModalGoster] = useState(false);
  const [isteModalGoster, setIsteModalGoster] = useState(false);
  const [tesekkurModalGoster, setTesekkurModalGoster] = useState(false);
  const [yardimEtModalGoster, setYardimEtModalGoster] = useState(false);
  const [talepEtModalGoster, setTalepEtModalGoster] = useState(false);
  
  const [verIcerik, setVerIcerik] = useState('');
  const [isteIcerik, setIsteIcerik] = useState('');
  const [tesekkurIcerik, setTesekkurIcerik] = useState('');
  const [yardimIcerik, setYardimIcerik] = useState('');
  const [talepIcerik, setTalepIcerik] = useState('');
  
  const [globalPaylas, setGlobalPaylas] = useState(false);
  const [kargoTeklifi, setKargoTeklifi] = useState(false);
  const [kargoOdemesi, setKargoOdemesi] = useState(false);
  const [toplamaYeri, setToplamaYeri] = useState('');

  const handleVerGonder = () => {
    console.log("Verilen: ", verIcerik);
    setVerModalGoster(false);
  };

  const handleIsteGonder = () => {
    console.log("İstenen: ", isteIcerik);
    setIsteModalGoster(false);
  };

  const handleTesekkurGonder = () => {
    console.log("Teşekkür: ", tesekkurIcerik);
    setTesekkurModalGoster(false);
  };

  const handleYardimEtGonder = () => {
    console.log("Yardım Teklifi: ", yardimIcerik);
    setYardimEtModalGoster(false);
  };

  const handleTalepEtGonder = () => {
    console.log("Yardım Talebi: ", talepIcerik);
    setTalepEtModalGoster(false);
  };

  return (
    <div className="share-page p-3">
      <h4 className="text-center mb-4">BN'de her şeyi ücretsiz veriyor, alıyor ve paylaşıyoruz. Satış, alım, kiralama, takas, pazarlama veya reklam yapmıyoruz.</h4>
      
      <div className="d-flex flex-column gap-3">
        {/* VER butonu */}
        <Button 
          variant="primary" 
          className="py-3"
          onClick={() => setVerModalGoster(true)}
        >
          <h5>Ver</h5>
          <small>Bir eşya veya hizmet</small>
        </Button>

        {/* İSTE butonu */}
        <Button 
          variant="success" 
          className="py-3"
          onClick={() => setIsteModalGoster(true)}
        >
          <h5>İste</h5>
          <small>Bir eşya veya hizmet</small>
        </Button>

        {/* TEŞEKKÜR butonu */}
        <Button 
          variant="warning" 
          className="py-3"
          onClick={() => setTesekkurModalGoster(true)}
        >
          <h5>Teşekkür</h5>
          <small>Minnetini ifade et</small>
        </Button>

      </div>

      <hr className="my-4" />

      {/* VER Modal */}
      <Modal show={verModalGoster} onHide={() => setVerModalGoster(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Ver</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>Bugün ne vermek istersiniz?</p>
          <Form.Control
            as="textarea"
            rows={3}
            value={verIcerik}
            onChange={(e) => setVerIcerik(e.target.value)}
            placeholder="Vermek istediğiniz eşya veya hizmeti açıklayın"
          />
          
          <Form.Check
            type="checkbox"
            label="Bu gönderiyi global olarak görünür yap"
            checked={globalPaylas}
            onChange={(e) => setGlobalPaylas(e.target.checked)}
            className="mt-3"
          />
          
          <Form.Check
            type="checkbox"
            label="BuyNothing Kargo ile göndermeyi teklif et"
            checked={kargoTeklifi}
            onChange={(e) => setKargoTeklifi(e.target.checked)}
            className="mt-2"
          />
          
          <Form.Group className="mt-3">
            <Form.Label>Toplanma Yeri (HERKESLE PAYLAŞILIR)</Form.Label>
            <Form.Control
              type="text"
              placeholder="Önemli bir yer veya kesişen sokaklar"
              value={toplamaYeri}
              onChange={(e) => setToplamaYeri(e.target.value)}
            />
          </Form.Group>
          
          <Form.Check
            type="checkbox"
            label="Bunu bir sonraki sefere sakla"
            className="mt-3"
          />
          
          <div className="mt-3">
            <small>HEDİYE GÖNDERİ DURUMU: YOK</small>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setVerModalGoster(false)}>
            İptal
          </Button>
          <Button variant="primary" onClick={handleVerGonder}>
            Gönder
          </Button>
        </Modal.Footer>
      </Modal>

      {/* İSTE Modal */}
      <Modal show={isteModalGoster} onHide={() => setIsteModalGoster(false)}>
        <Modal.Header closeButton>
          <Modal.Title>İste</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>Ne istemek istersiniz?</p>
          <Form.Control
            as="textarea"
            rows={3}
            value={isteIcerik}
            onChange={(e) => setIsteIcerik(e.target.value)}
            placeholder="İstediğiniz eşya veya hizmeti açıklayın"
          />
          
          <Form.Check
            type="checkbox"
            label="Bu gönderiyi global olarak görünür yap"
            checked={globalPaylas}
            onChange={(e) => setGlobalPaylas(e.target.checked)}
            className="mt-3"
          />
          
          <Form.Check
            type="checkbox"
            label="BuyNothing Kargo ile bana gönderilmesi için ödeme yapmaya hazırım"
            checked={kargoOdemesi}
            onChange={(e) => setKargoOdemesi(e.target.checked)}
            className="mt-2"
          />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setIsteModalGoster(false)}>
            İptal
          </Button>
          <Button variant="success" onClick={handleIsteGonder}>
            Gönder
          </Button>
        </Modal.Footer>
      </Modal>

      {/* TEŞEKKÜR Modal */}
      <Modal show={tesekkurModalGoster} onHide={() => setTesekkurModalGoster(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Teşekkür</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>Bugün neye minnettarsınız?</p>
          <Form.Control
            as="textarea"
            rows={3}
            value={tesekkurIcerik}
            onChange={(e) => setTesekkurIcerik(e.target.value)}
            placeholder="Minnettar olduğunuz şeyi paylaşın"
          />
          
          <Form.Check
            type="checkbox"
            label="Bu gönderiyi global olarak görünür yap"
            checked={globalPaylas}
            onChange={(e) => setGlobalPaylas(e.target.checked)}
            className="mt-3"
          />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setTesekkurModalGoster(false)}>
            İptal
          </Button>
          <Button variant="warning" onClick={handleTesekkurGonder}>
            Gönder
          </Button>
        </Modal.Footer>
      </Modal>

      {/* YARDIM ET Modal (Mavi butona basınca) */}
      <Modal show={yardimEtModalGoster} onHide={() => setYardimEtModalGoster(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Yardım Et</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>Nasıl yardım etmek istersiniz?</p>
          <Form.Control
            as="textarea"
            rows={3}
            value={yardimIcerik}
            onChange={(e) => setYardimIcerik(e.target.value)}
            placeholder="Yardım teklifinizi açıklayın"
          />
          
          <Form.Check
            type="checkbox"
            label="Bu gönderiyi global olarak görünür yap"
            checked={globalPaylas}
            onChange={(e) => setGlobalPaylas(e.target.checked)}
            className="mt-3"
          />
          
          <Form.Group className="mt-3">
            <Form.Label>Yardım Sağlanabilecek Yer</Form.Label>
            <Form.Control
              type="text"
              placeholder="Yardımı nerede sağlayabileceğinizi belirtin"
              value={toplamaYeri}
              onChange={(e) => setToplamaYeri(e.target.value)}
            />
          </Form.Group>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setYardimEtModalGoster(false)}>
            İptal
          </Button>
          <Button variant="info" onClick={handleYardimEtGonder}>
            Gönder
          </Button>
        </Modal.Footer>
      </Modal>

      {/* TALEP ET Modal (Yeşil butona basınca) */}
      <Modal show={talepEtModalGoster} onHide={() => setTalepEtModalGoster(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Yardım Talebi</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>Ne tür bir yardıma ihtiyacınız var?</p>
          <Form.Control
            as="textarea"
            rows={3}
            value={talepIcerik}
            onChange={(e) => setTalepIcerik(e.target.value)}
            placeholder="Yardım talebinizi açıklayın"
          />
          
          <Form.Check
            type="checkbox"
            label="Bu gönderiyi global olarak görünür yap"
            checked={globalPaylas}
            onChange={(e) => setGlobalPaylas(e.target.checked)}
            className="mt-3"
          />
          
          <Form.Group className="mt-3">
            <Form.Label>Yardım Alınabilecek Yer</Form.Label>
            <Form.Control
              type="text"
              placeholder="Yardımı nerede alabileceğinizi belirtin"
              value={toplamaYeri}
              onChange={(e) => setToplamaYeri(e.target.value)}
            />
          </Form.Group>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setTalepEtModalGoster(false)}>
            İptal
          </Button>
          <Button variant="success" onClick={handleTalepEtGonder}>
            Gönder
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default Share;