import React from 'react';
import { Navbar, Button } from 'react-bootstrap';
import { House, Inbox, Share, Person, People } from 'react-bootstrap-icons';
import { Link, useLocation } from 'react-router-dom';

const BottomNav = () => {
  const location = useLocation();
  const hideBottomNavPaths = ['/', '/manual-entry', '/community-confirmation'];
  
  // Don't show bottom nav on these paths
  if (hideBottomNavPaths.includes(location.pathname)) {
    return null;
  }

  return (
    
    <Navbar bg="white" fixed="bottom" className="border-top justify-content-around py-2 shadow-sm">
      <Button 
        as={Link} 
        to="/home" 
        variant="link" 
        className={`d-flex flex-column align-items-center ${location.pathname === '/home' ? 'text-success' : 'text-dark'}`}
        
      >
        <House size={20} />
        <small>Anasayfa</small>
      </Button>
      <Button 
        as={Link} 
        to="/inbox" 
        variant="link" 
        className={`d-flex flex-column align-items-center ${location.pathname === '/inbox' ? 'text-success' : 'text-dark'}`}
      >
        <Inbox size={20} />
        <small>Mesajlar</small>
      </Button>
      <Button 
        as={Link} 
        to="/share" 
        variant="link" 
        className={`d-flex flex-column align-items-center ${location.pathname === '/share' ? 'text-success' : 'text-dark'}`}
      >
        <Share size={20} />
        <small>Paylaş</small>
      </Button>
      <Button 
        as={Link} 
        to="/profile" 
        variant="link" 
        className={`d-flex flex-column align-items-center ${location.pathname === '/profile' ? 'text-success' : 'text-dark'}`}
      >
        <Person size={20} />
        <small>Profil</small>
      </Button>
      <Button 
        as={Link} 
        to="/community" 
        variant="link" 
        className={`d-flex flex-column align-items-center ${location.pathname === '/community' ? 'text-success' : 'text-dark'}`}
      >
        <People size={20} />
        <small>Topluluk</small>
      </Button>
    </Navbar>
  );
};

export default BottomNav;