import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

export default function GizlilikPolitikasi() {
  return (
    <main className="flex min-h-screen flex-col">
      

      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-b from-green-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl font-bold mb-6">
              Gizlilik Politikası
            </h1>
            <p className="text-xl text-gray-600">
              YanKapı olarak kişisel verilerinizin güvenliği bizim için çok önemli.
            </p>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto prose prose-lg">
            <h2>1. Genel Bilgilendirme</h2>
            <p>
              Bu gizlilik politikası, YanKapı mobil uygulaması ve web sitesi üzerinden toplanan verilerin nasıl kullanıldığını ve korunduğunu açıklar. Uygulamayı kullanarak bu politikayı kabul etmiş olursunuz.
            </p>

            <h2>2. Toplanan Veriler</h2>
            <p>
              YanKapı üzerinden aşağıdaki kişisel veriler toplanmaktadır:
            </p>
            <ul>
              <li>Ad ve soyad</li>
              <li>Telefon numarası</li>
              <li>E-posta adresi</li>
              <li>Adres bilgileri</li>
              <li>Konum bilgileri</li>
              <li>Profil fotoğrafı (isteğe bağlı)</li>
            </ul>

            <h2>3. Verilerin Kullanımı</h2>
            <p>
              Toplanan veriler aşağıdaki amaçlar için kullanılmaktadır:
            </p>
            <ul>
              <li>Kullanıcı hesabının oluşturulması ve yönetimi</li>
              <li>Mahalle bazlı yardımlaşma sisteminin işletilmesi</li>
              <li>Güvenlik ve doğrulama işlemleri</li>
              <li>Kullanıcı deneyiminin iyileştirilmesi</li>
              <li>Yasal yükümlülüklerin yerine getirilmesi</li>
            </ul>

            <h2>4. Veri Güvenliği</h2>
            <p>
              Kişisel verileriniz endüstri standardı güvenlik önlemleri ile korunmaktadır:
            </p>
            <ul>
              <li>SSL/TLS şifreleme</li>
              <li>Güvenli veri depolama</li>
              <li>Düzenli güvenlik denetimleri</li>
              <li>Erişim kontrolü ve yetkilendirme</li>
            </ul>

            <h2>5. Veri Paylaşımı</h2>
            <p>
              Kişisel verileriniz, açık rızanız olmadan üçüncü taraflarla paylaşılmaz. Ancak aşağıdaki durumlarda veri paylaşımı yapılabilir:
            </p>
            <ul>
              <li>Yasal zorunluluk durumunda</li>
              <li>Kullanıcı güvenliğinin sağlanması için</li>
              <li>Platform hizmetlerinin sağlanması amacıyla</li>
            </ul>

            <h2>6. Çerezler</h2>
            <p>
              Web sitemizde kullanıcı deneyimini iyileştirmek için çerezler kullanılmaktadır. Çerez kullanımını tarayıcı ayarlarınızdan kontrol edebilirsiniz.
            </p>

            <h2>7. Kullanıcı Hakları</h2>
            <p>
              KVKK kapsamında aşağıdaki haklara sahipsiniz:
            </p>
            <ul>
              <li>Kişisel verilerinizin işlenip işlenmediğini öğrenme</li>
              <li>Kişisel verileriniz işlenmişse buna ilişkin bilgi talep etme</li>
              <li>Kişisel verilerinizin işlenme amacını ve bunların amacına uygun kullanılıp kullanılmadığını öğrenme</li>
              <li>Yurt içinde veya yurt dışında kişisel verilerinizin aktarıldığı üçüncü kişileri bilme</li>
              <li>Kişisel verilerinizin eksik veya yanlış işlenmiş olması hâlinde bunların düzeltilmesini isteme</li>
              <li>KVKK'nın 7. maddesinde öngörülen şartlar çerçevesinde kişisel verilerinizin silinmesini veya yok edilmesini isteme</li>
            </ul>

            <h2>8. İletişim</h2>
            <p>
              Gizlilik politikası ile ilgili sorularınız için aşağıdaki kanallardan bize ulaşabilirsiniz:
            </p>
            <ul>
              <li>E-posta: privacy@yankapi.com</li>
              <li>Telefon: 0850 123 45 67</li>
              <li>Adres: Örnek Mahallesi, Teknoloji Caddesi No:1, İstanbul</li>
            </ul>

            <h2>9. Güncellemeler</h2>
            <p>
              Bu gizlilik politikası periyodik olarak güncellenebilir. Önemli değişiklikler olması durumunda kullanıcılarımız bilgilendirilecektir.
            </p>
            <p className="text-sm text-gray-500 mt-8">
              Son güncelleme: 1 Mart 2024
            </p>
          </div>
        </div>
      </section>

     
    </main>
  );
} 