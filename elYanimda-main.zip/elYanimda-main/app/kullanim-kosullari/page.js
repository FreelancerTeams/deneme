import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

export default function KullanimKosullari() {
  return (
    <main className="flex min-h-screen flex-col">
      

      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-b from-green-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl font-bold mb-6">
              Kullanım Koşulları
            </h1>
            <p className="text-xl text-gray-600">
              YanKapı'yı kullanmadan önce lütfen bu koşulları dikkatlice okuyun.
            </p>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto prose prose-lg">
            <h2>1. Genel Hükümler</h2>
            <p>
              Bu kullanım koşulları, YanKapı mobil uygulaması ve web sitesinin kullanımını düzenler. Uygulamayı kullanarak bu koşulları kabul etmiş olursunuz.
            </p>

            <h2>2. Üyelik</h2>
            <p>
              YanKapı'ya üye olabilmek için:
            </p>
            <ul>
              <li>18 yaşından büyük olmanız</li>
              <li>Gerçek ve güncel bilgiler vermeniz</li>
              <li>Telefon numaranızı doğrulamanız</li>
              <li>Adres bilgilerinizi doğrulamanız</li>
              <li>Bu kullanım koşullarını kabul etmeniz gerekmektedir</li>
            </ul>

            <h2>3. Kullanım Kuralları</h2>
            <p>
              YanKapı kullanıcıları aşağıdaki kurallara uymakla yükümlüdür:
            </p>
            <ul>
              <li>Yalnızca yasal amaçlar için kullanım</li>
              <li>Diğer kullanıcılara saygılı davranma</li>
              <li>Doğru ve güncel bilgi paylaşma</li>
              <li>Spam ve yanıltıcı içerikten kaçınma</li>
              <li>Gizlilik ve güvenlik kurallarına uyma</li>
            </ul>

            <h2>4. Yardımlaşma Kuralları</h2>
            <p>
              Platform üzerinden yapılacak yardımlaşmalarda:
            </p>
            <ul>
              <li>Yardımlar tamamen gönüllülük esasına dayanır</li>
              <li>Herhangi bir ücret talep edilemez</li>
              <li>Yasal olmayan yardım talepleri yasaktır</li>
              <li>Yardım talepleri açık ve net olmalıdır</li>
              <li>Güvenlik için belirlenen kurallara uyulmalıdır</li>
            </ul>

            <h2>5. Yasaklı İçerikler</h2>
            <p>
              Aşağıdaki içeriklerin paylaşılması kesinlikle yasaktır:
            </p>
            <ul>
              <li>Yasadışı içerikler</li>
              <li>Nefret söylemi ve ayrımcılık</li>
              <li>Şiddet ve tehdit içeren paylaşımlar</li>
              <li>Yanıltıcı ve spam içerikler</li>
              <li>Telif hakkı ihlali</li>
            </ul>

            <h2>6. Hesap Güvenliği</h2>
            <p>
              Kullanıcılar hesap güvenliği için:
            </p>
            <ul>
              <li>Güçlü şifre kullanmalı</li>
              <li>Hesap bilgilerini gizli tutmalı</li>
              <li>Şüpheli durumları bildirmeli</li>
              <li>Düzenli güvenlik kontrolü yapmalı</li>
            </ul>

            <h2>7. Sorumluluk Reddi</h2>
            <p>
              YanKapı:
            </p>
            <ul>
              <li>Kullanıcılar arası anlaşmazlıklarda taraf değildir</li>
              <li>Yardımlaşma sürecinde oluşabilecek zararlardan sorumlu değildir</li>
              <li>Platform kesintilerinden kaynaklı sorunlardan sorumlu değildir</li>
              <li>İçeriklerin doğruluğunu garanti etmez</li>
            </ul>

            <h2>8. Hesap Askıya Alma ve Sonlandırma</h2>
            <p>
              YanKapı aşağıdaki durumlarda hesapları askıya alabilir veya sonlandırabilir:
            </p>
            <ul>
              <li>Kullanım koşullarının ihlali</li>
              <li>Yasadışı faaliyetler</li>
              <li>Diğer kullanıcılara zarar verme</li>
              <li>Spam ve kötüye kullanım</li>
              <li>Sahte hesap oluşturma</li>
            </ul>

            <h2>9. Değişiklikler</h2>
            <p>
              YanKapı, bu kullanım koşullarını önceden haber vermeksizin değiştirme hakkını saklı tutar. Önemli değişiklikler kullanıcılara bildirilecektir.
            </p>

            <h2>10. İletişim</h2>
            <p>
              Kullanım koşulları ile ilgili sorularınız için:
            </p>
            <ul>
              <li>E-posta: info@yankapi.com</li>
              <li>Telefon: 0850 123 45 67</li>
              <li>Adres: Örnek Mahallesi, Teknoloji Caddesi No:1, İstanbul</li>
            </ul>

            <p className="text-sm text-gray-500 mt-8">
              Son güncelleme: 1 Mart 2024
            </p>
          </div>
        </div>
      </section>

     
    </main>
  );
} 