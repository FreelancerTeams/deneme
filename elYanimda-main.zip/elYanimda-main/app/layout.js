import { Inter } from "next/font/google";
import "./globals.css";
import Image from "next/image";
import Link from "next/link";

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "YanKapı - Mahalle Yardımlaşma Platformu",
  description: "Mahallenizde dayanışmayı güçlendirin, ihtiyaç sahiplerine yardım edin, topluluk bağlarını güçlendirin.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="tr">
      <body className={inter.className}>
        <header className="fixed top-0 left-0 right-0 bg-white shadow-sm z-50">
          <nav className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <Link href="/" className="text-2xl font-bold text-green-600">
                YanKapı
              </Link>
              <div className="hidden md:flex items-center gap-8">
                <Link href="/" className="text-gray-600 hover:text-green-600">
                  Ana Sayfa
                </Link>
                <Link href="/nasil-calisir" className="text-gray-600 hover:text-green-600">
                  Nasıl Çalışır?
                </Link>
                <Link href="/sss" className="text-gray-600 hover:text-green-600">
                  S.S.S
                </Link>
                <Link href="/iletisim" className="text-gray-600 hover:text-green-600">
                  İletişim
                </Link>
                <button className="rounded-full bg-green-600 px-6 py-2 text-white hover:bg-green-700">
                  Uygulamayı İndir
                </button>
              </div>
            </div>
          </nav>
        </header>
        
        <main className="pt-20">
          {children}
        </main>

        <section className="bg-green-50 py-20">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl font-bold mb-6">YanKapı Mobil Uygulaması</h2>
                <p className="text-gray-600 mb-8">
                  Mahalle dayanışmasını cebinize getiriyoruz! YanKapı mobil uygulaması ile yardımlaşma artık çok daha kolay.
                </p>
                <div className="flex gap-4">
                  <button className="bg-black text-white px-6 py-3 rounded-lg flex items-center gap-2">
                    <Image src="/app-store.svg" alt="App Store" width={24} height={24} />
                    App Store
                  </button>
                  <button className="bg-black text-white px-6 py-3 rounded-lg flex items-center gap-2">
                    <Image src="/play-store.svg" alt="Play Store" width={24} height={24} />
                    Play Store
                  </button>
                </div>
              </div>
              <div className="relative h-[600px]">
                <div className="absolute inset-0 bg-gradient-to-b from-green-100 to-transparent rounded-3xl">
                  <Image
                    src="/phone-mockup.png"
                    alt="YanKapı Mobil Uygulama"
                    width={300}
                    height={600}
                    className="mx-auto"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>
        
        <footer className="bg-gray-900 text-white py-12">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4">YanKapı</h3>
                <p className="text-gray-400">
                  Mahalle bazlı yardımlaşma ve dayanışma platformu.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-4">Hızlı Bağlantılar</h4>
                <ul className="space-y-2">
                  <li>
                    <Link href="/nasil-calisir" className="text-gray-400 hover:text-white">
                      Nasıl Çalışır?
                    </Link>
                  </li>
                  <li>
                    <Link href="/sss" className="text-gray-400 hover:text-white">
                      S.S.S
                    </Link>
                  </li>
                  <li>
                    <Link href="/iletisim" className="text-gray-400 hover:text-white">
                      İletişim
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-4">İletişim</h4>
                <ul className="space-y-2">
                  <li>
                    <Link href="mailto:info@yankapi.com" className="text-gray-400 hover:text-white">
                      info@yankapi.com
                    </Link>
                  </li>
                  <li className="text-gray-400">
                    0850 123 45 67
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-4">Mobil Uygulama</h4>
                <div className="flex flex-col gap-2">
                  <Link href="#" className="text-gray-400 hover:text-white">
                    App Store
                  </Link>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Google Play
                  </Link>
                </div>
              </div>
            </div>
            <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
              <p>&copy; 2024 YanKapı. Tüm hakları saklıdır.</p>
            </div>
          </div>
        </footer>
      </body>
    </html>
  );
}
