import HeroSlider from './components/HeroSlider';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col">
     
      <HeroSlider />

      {/* App Download Section */}
      <section className="w-full py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl font-bold mb-6">Mobil Uygulamamızı İndirin</h2>
                <p className="text-gray-600 mb-8">
                  YanKapı mobil uygulaması ile yardımlaşma artık çok daha kolay. 
                  Hemen indirin ve mahalle dayanışmasına katılın.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <a href="#" className="flex items-center justify-center bg-black text-white rounded-xl px-6 py-3 hover:bg-gray-900">
                    <svg className="w-8 h-8 mr-2" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.78 1.18-.19 2.31-.89 3.51-.84 1.54.07 2.7.61 3.44 1.57-3.14 1.88-2.29 5.97.67 7.05-.59 1.2-1.31 2.37-2.7 4.41zm-3.11-17.45c-.04 1.82 1.45 3.26 3.14 3.11.13-1.93-1.55-3.29-3.14-3.11z"/>
                    </svg>
                    App Store
                  </a>
                  <a href="#" className="flex items-center justify-center bg-black text-white rounded-xl px-6 py-3 hover:bg-gray-900">
                    <svg className="w-8 h-8 mr-2" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M3.609 1.814L13.792 12 3.61 22.186a.996.996 0 0 1-.61-.92V2.734a1 1 0 0 1 .609-.92zm10.89 10.184l2.81-2.81 4.383 2.54c.55.318.89.906.89 1.542 0 .636-.34 1.224-.89 1.542l-4.382 2.54-2.81-2.81 2.81-2.544-2.81-2.54zm-.517-4.076L8.818 3.76 20.381 12l-6.164 3.576 3.764-3.576-3.764-3.42z"/>
                    </svg>
                    Google Play
                  </a>
                </div>
              </div>
              <div className="relative">
                <img 
                  src="/mobile-app.png" 
                  alt="YanKapı Mobil Uygulama" 
                  className="w-full rounded-2xl shadow-2xl"
                />
                <div className="absolute -top-4 -right-4 bg-green-100 rounded-full p-4">
                  <span className="text-green-600 font-semibold">Ücretsiz</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="w-full py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-center mb-16">Neler Sunuyoruz?</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-8 rounded-xl shadow-sm">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-4">Mahalle Bazlı</h3>
                <p className="text-gray-600">Güvenli ve tanıdık bir ortamda yardımlaşın</p>
              </div>
              <div className="bg-white p-8 rounded-xl shadow-sm">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-4">Kolay Kullanım</h3>
                <p className="text-gray-600">Basit arayüz ile hızlıca yardım edin veya alın</p>
              </div>
              <div className="bg-white p-8 rounded-xl shadow-sm">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-4">Güvenli Platform</h3>
                <p className="text-gray-600">Doğrulanmış kullanıcılar ile güvenli yardımlaşma</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-24 bg-green-600">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center text-white">
            <h2 className="text-4xl font-bold mb-8">
              Hemen Yardımlaşmaya Başlayın
            </h2>
            <p className="text-xl mb-12 opacity-90">
              Ücretsiz uygulamayı indirin, mahallenizdeki yardımlaşma ağına katılın
            </p>
            <div className="flex justify-center gap-4">
              <button className="rounded-full bg-white px-8 py-4 text-green-600 hover:bg-gray-100 transition-all">
                Uygulamayı İndir
              </button>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
