'use client';

import { useState } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

export default function SSS() {
  const [openQuestion, setOpenQuestion] = useState(null);

  const questions = [
    {
      question: "YanKapı nedir?",
      answer: "YanKapı, mahalle sakinlerinin birbirleriyle yardımlaşmasını kolaylaştıran ücretsiz bir mobil uygulamadır. Platform, aynı mahallede yaşayan insanları bir araya getirerek güvenli ve etkili bir yardımlaşma ağı oluşturur."
    },
    {
      question: "Nasıl üye olabilirim?",
      answer: "App Store veya Google Play'den YanKapı uygulamasını indirdikten sonra, telefon numaranız ile hızlıca üye olabilirsiniz. Üyelik işlemi sırasında mahallenizi seçmeniz ve adres doğrulaması yapmanız gerekecektir."
    },
    {
      question: "Uygulama ücretsiz mi?",
      answer: "Evet, YanKapı tamamen ücretsizdir. Uygulama içinde herhangi bir ücretli özellik veya premium üyelik bulunmamaktadır."
    },
    {
      question: "Nasıl yardım isteyebilirim?",
      answer: "Uygulamada 'Yardım İste' butonuna tıklayarak ihtiyacınızı belirtebilirsiniz. İhtiyacınızın türünü, aciliyetini ve detaylarını girdikten sonra, mahallenizdeki diğer kullanıcılar bildirim alacak ve size yardım edebilecekler."
    },
    {
      question: "Sistem nasıl güvenli kalıyor?",
      answer: "YanKapı'da güvenlik bizim için çok önemli. Tüm kullanıcıların telefon numaraları ve adresleri doğrulanır. Ayrıca, kullanıcılar sadece kendi mahallelerindeki kişilerle etkileşime geçebilir ve her kullanıcı için puanlama sistemi bulunur."
    },
    {
      question: "Hangi tür yardımlar isteyebilirim?",
      answer: "YanKapı üzerinden çeşitli konularda yardım isteyebilirsiniz: Eşya taşıma, market alışverişi, evcil hayvan bakımı, teknik destek, ve benzeri günlük ihtiyaçlar için yardım talep edebilirsiniz."
    },
    {
      question: "Puanlama sistemi nasıl çalışır?",
      answer: "Her başarılı yardımlaşma sonrası, kullanıcılar birbirlerine puan ve yorum bırakabilir. Bu puanlar ve yorumlar, diğer kullanıcılar için güvenilirlik göstergesi olarak kullanılır."
    },
    {
      question: "Bir sorun yaşarsam ne yapmalıyım?",
      answer: "Uygulama içindeki 'Destek' bölümünden bize ulaşabilirsiniz. 7/24 destek ekibimiz size yardımcı olmak için hazır beklemektedir."
    },
    {
      question: "Mahallemi değiştirebilir miyim?",
      answer: "Evet, taşınma durumunda mahalle bilginizi güncelleyebilirsiniz. Yeni adresinizin doğrulaması yapıldıktan sonra, yeni mahallenizdeki yardımlaşma ağına katılabilirsiniz."
    },
    {
      question: "Kişisel verilerim nasıl korunuyor?",
      answer: "Kişisel verileriniz KVKK kapsamında korunmaktadır. Verileriniz şifrelenerek saklanır ve üçüncü taraflarla paylaşılmaz. Detaylı bilgi için Gizlilik Politikamızı inceleyebilirsiniz."
    }
  ];

  return (
    <main className="flex min-h-screen flex-col">
      

      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-b from-green-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl font-bold mb-6">
              Sıkça Sorulan Sorular
            </h1>
            <p className="text-xl text-gray-600">
              YanKapı hakkında merak ettiğiniz tüm soruların cevapları burada.
            </p>
          </div>
        </div>
      </section>

      {/* Questions Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="space-y-4">
              {questions.map((item, index) => (
                <div
                  key={index}
                  className="bg-white rounded-xl border border-gray-200 overflow-hidden"
                >
                  <button
                    className="w-full px-6 py-4 text-left flex justify-between items-center"
                    onClick={() => setOpenQuestion(openQuestion === index ? null : index)}
                  >
                    <span className="text-lg font-semibold">{item.question}</span>
                    <svg
                      className={`w-6 h-6 transform transition-transform ${
                        openQuestion === index ? 'rotate-180' : ''
                      }`}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M19 9l-7 7-7-7"
                      />
                    </svg>
                  </button>
                  <div
                    className={`px-6 overflow-hidden transition-all duration-200 ${
                      openQuestion === index ? 'max-h-96 py-4' : 'max-h-0'
                    }`}
                  >
                    <p className="text-gray-600">{item.answer}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">
              Başka Sorunuz Var Mı?
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Aradığınız cevabı bulamadıysanız, destek ekibimiz size yardımcı olmaktan mutluluk duyacaktır.
            </p>
            <button className="bg-green-600 text-white px-8 py-4 rounded-full hover:bg-green-700 transition-all">
              Destek Ekibine Ulaşın
            </button>
          </div>
        </div>
      </section>

     
    </main>
  );
} 