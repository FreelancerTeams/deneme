'use client';

import { useState, useEffect } from 'react';

export default function HeroSlider() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      image: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80",
      title: "Yardımsever Komşular",
      description: "Mahallenizde güvenilir yardım eli"
    },
    {
      image: "https://images.unsplash.com/photo-1590779033100-9f60a05a013d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80",
      title: "Güçlü Topluluk",
      description: "Birlikte daha güçlüyüz"
    },
    {
      image: "https://images.unsplash.com/photo-1592647420148-bfcc177e2117?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80",
      title: "Anlık Yardımlaşma",
      description: "İhtiyaç anında hemen yanınızda"
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="relative w-full min-h-screen">
      {/* Hero Content */}
      <div className="absolute inset-0 z-10">
        <div className="container mx-auto px-4 h-full flex items-center">
          <div className="max-w-2xl">
            <h1 className="text-7xl font-bold text-white mb-6 leading-tight">
              Yardımlaşmanın<br />
              Yeni Adresi
            </h1>
            <p className="text-xl text-white/90 mb-8 max-w-lg">
              Mahallenizde güvenilir yardımlaşma platformu ile tanışın.
              Komşularınızla dayanışmanın gücünü keşfedin.
            </p>
            <div className="flex gap-4">
              <button className="bg-white text-gray-900 px-8 py-4 rounded-full font-medium hover:bg-gray-100 transition-all">
                Yardım Bul
              </button>
              <button className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-full font-medium hover:bg-white/10 transition-all">
                Nasıl Çalışır?
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Slider */}
      <div className="absolute inset-0 bg-black/40 z-0"></div>
      <div className="relative h-screen overflow-hidden">
        {slides.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              currentSlide === index ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <img
              src={slide.image}
              alt={slide.title}
              className="w-full h-full object-cover"
            />
          </div>
        ))}
      </div>

      {/* Slider Navigation */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20">
        <div className="flex gap-3">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-3 h-3 rounded-full transition-all ${
                currentSlide === index ? 'bg-white scale-125' : 'bg-white/50'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
} 